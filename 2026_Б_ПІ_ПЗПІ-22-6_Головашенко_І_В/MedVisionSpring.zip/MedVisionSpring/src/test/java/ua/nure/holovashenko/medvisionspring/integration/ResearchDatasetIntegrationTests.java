package ua.nure.holovashenko.medvisionspring.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import ua.nure.holovashenko.medvisionspring.dto.DatasetSplitCreateRequest;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.service.ResearchDatasetService;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class ResearchDatasetIntegrationTests {
    @Autowired private ResearchDatasetService service;
    @Autowired private UserRepository userRepository;
    @Autowired private ResearchDatasetRepository datasetRepository;
    @Autowired private DatasetItemRepository itemRepository;
    @Autowired private DatasetSplitAssignmentRepository assignmentRepository;
    @Autowired private ImageFileRepository imageFileRepository;

    @Test
    void deterministicSplitHasNoOverlapAndFrozenDatasetIsImmutable() {
        String suffix = UUID.randomUUID().toString();
        User user = userRepository.save(User.builder().userName("Research Admin").email(suffix + "@example.com")
                .pw("encoded").userRole(UserRole.ADMIN).build());
        ResearchDataset dataset = datasetRepository.save(ResearchDataset.builder().name("dataset-" + suffix).version("1")
                .status(ResearchDatasetStatus.DRAFT).createdBy(user).build());
        for (int index = 0; index < 10; index++) {
            ImageFile image = imageFileRepository.save(ImageFile.builder().imageFileUrl("file:///tmp/" + suffix + index)
                    .imageFileName("image-" + index + ".png").imageFileType("image/png").uploadedAt(LocalDateTime.now())
                    .uploadedBy(user).storageKey("dataset-test/" + suffix + index).originalFileName("image.png")
                    .sizeBytes(1L).checksumSha256("0".repeat(64)).contentTypeVerified(true).build());
            itemRepository.save(DatasetItem.builder().dataset(dataset).imageFile(image).classLabel(index % 2)
                    .labelSource(DatasetLabelSource.MANUAL).reviewedBy(user).reviewedAt(LocalDateTime.now()).build());
        }
        DatasetSplitCreateRequest request = new DatasetSplitCreateRequest(0.6, 0.2, 0.2, 42L);
        service.split(dataset.getDatasetId(), request);
        Map<Long, DatasetSplit> first = assignments(dataset);
        service.split(dataset.getDatasetId(), request);
        Map<Long, DatasetSplit> second = assignments(dataset);

        assertThat(second).hasSize(10).isEqualTo(first);
        assertThat(second.values()).contains(DatasetSplit.TRAIN, DatasetSplit.VALIDATION, DatasetSplit.TEST);
        service.freeze(dataset.getDatasetId());
        assertThatThrownBy(() -> service.split(dataset.getDatasetId(), request)).isInstanceOf(ApiException.class);
    }

    private Map<Long, DatasetSplit> assignments(ResearchDataset dataset) {
        return assignmentRepository.findAllByDataset(dataset).stream().collect(Collectors.toMap(
                assignment -> assignment.getDatasetItem().getDatasetItemId(), DatasetSplitAssignment::getDatasetSplit));
    }
}
