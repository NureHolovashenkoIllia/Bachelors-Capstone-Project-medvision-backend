package ua.nure.holovashenko.medvisionspring.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.ApplicationArguments;
import org.springframework.security.crypto.password.PasswordEncoder;
import ua.nure.holovashenko.medvisionspring.config.AdminBootstrapProperties;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdminBootstrapRunnerTests {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private ApplicationArguments applicationArguments;

    @Test
    void disabledBootstrapDoesNotAccessRepository() {
        AdminBootstrapRunner runner = runner(false, "", "", "");

        runner.run(applicationArguments);

        verifyNoInteractions(userRepository, passwordEncoder);
    }

    @Test
    void enabledBootstrapCreatesFirstAdministrator() {
        AdminBootstrapRunner runner = runner(
                true,
                "Initial Administrator",
                "admin@example.com",
                "StrongPassword123!"
        );
        when(userRepository.existsByUserRole(UserRole.ADMIN)).thenReturn(false);
        when(userRepository.existsByEmail("admin@example.com")).thenReturn(false);
        when(passwordEncoder.encode("StrongPassword123!")).thenReturn("encoded-password");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setUserId(1L);
            return user;
        });

        runner.run(applicationArguments);

        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(captor.capture());
        User administrator = captor.getValue();
        assertThat(administrator.getUserName()).isEqualTo("Initial Administrator");
        assertThat(administrator.getEmail()).isEqualTo("admin@example.com");
        assertThat(administrator.getPw()).isEqualTo("encoded-password");
        assertThat(administrator.getUserRole()).isEqualTo(UserRole.ADMIN);
    }

    @Test
    void existingAdministratorMakesBootstrapIdempotent() {
        AdminBootstrapRunner runner = runner(true, "", "", "");
        when(userRepository.existsByUserRole(UserRole.ADMIN)).thenReturn(true);

        runner.run(applicationArguments);

        verify(userRepository, never()).save(any(User.class));
        verifyNoInteractions(passwordEncoder);
    }

    @Test
    void duplicateEmailPreventsBootstrap() {
        AdminBootstrapRunner runner = runner(
                true,
                "Initial Administrator",
                "admin@example.com",
                "StrongPassword123!"
        );
        when(userRepository.existsByUserRole(UserRole.ADMIN)).thenReturn(false);
        when(userRepository.existsByEmail("admin@example.com")).thenReturn(true);

        assertThatThrownBy(() -> runner.run(applicationArguments))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("Administrator bootstrap email is already assigned to another user");

        verify(userRepository, never()).save(any(User.class));
        verifyNoInteractions(passwordEncoder);
    }

    @Test
    void weakPasswordPreventsBootstrap() {
        AdminBootstrapRunner runner = runner(
                true,
                "Initial Administrator",
                "admin@example.com",
                "short"
        );
        when(userRepository.existsByUserRole(UserRole.ADMIN)).thenReturn(false);

        assertThatThrownBy(() -> runner.run(applicationArguments))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("MEDVISION_BOOTSTRAP_ADMIN_PASSWORD must contain at least 12 characters");

        verify(userRepository, never()).save(any(User.class));
        verifyNoInteractions(passwordEncoder);
    }

    private AdminBootstrapRunner runner(
            boolean enabled,
            String name,
            String email,
            String password
    ) {
        AdminBootstrapProperties properties = new AdminBootstrapProperties(enabled, name, email, password);
        return new AdminBootstrapRunner(properties, userRepository, passwordEncoder);
    }
}
