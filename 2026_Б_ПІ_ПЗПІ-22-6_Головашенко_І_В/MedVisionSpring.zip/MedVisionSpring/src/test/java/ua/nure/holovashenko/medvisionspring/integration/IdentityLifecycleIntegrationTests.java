package ua.nure.holovashenko.medvisionspring.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import ua.nure.holovashenko.medvisionspring.entity.Hospital;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.HospitalStatus;
import ua.nure.holovashenko.medvisionspring.enums.MembershipStatus;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.repository.AuthSessionRepository;
import ua.nure.holovashenko.medvisionspring.repository.DoctorRepository;
import ua.nure.holovashenko.medvisionspring.repository.HospitalRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserHospitalMembershipRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.util.email.EmailService;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class IdentityLifecycleIntegrationTests {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private HospitalRepository hospitalRepository;
    @Autowired
    private UserHospitalMembershipRepository membershipRepository;
    @Autowired
    private AuthSessionRepository sessionRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @MockBean
    private EmailService emailService;

    @Test
    void invitationSessionResetDisableAndAuditWorkEndToEnd() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        User admin = userRepository.save(User.builder()
                .userName("Lifecycle Admin")
                .email("lifecycle-admin-" + suffix + "@example.com")
                .pw(passwordEncoder.encode("AdminPassword123"))
                .userRole(UserRole.ADMIN)
                .accountStatus(UserAccountStatus.ACTIVE)
                .build());
        Hospital hospital = hospitalRepository.save(Hospital.builder()
                .name("Lifecycle Clinic " + suffix)
                .legalName("Lifecycle Clinic LLC")
                .code("LC-" + suffix)
                .status(HospitalStatus.ACTIVE)
                .build());
        String doctorEmail = "invited-doctor-" + suffix + "@example.com";

        String invitationBody = mockMvc.perform(post("/api/admin/invitations/doctors")
                        .with(user(admin.getEmail()).roles("ADMIN"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "hospitalId": %d,
                                  "email": "%s",
                                  "name": "Invited Doctor",
                                  "hospitalRole": "DOCTOR",
                                  "position": "Radiologist",
                                  "department": "Diagnostics",
                                  "licenseNumber": "LIC-%s"
                                }
                                """.formatted(hospital.getHospitalId(), doctorEmail, suffix)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andReturn().getResponse().getContentAsString();
        String invitationToken = objectMapper.readTree(invitationBody).get("token").asText();
        verify(emailService).sendDoctorInvitation(org.mockito.ArgumentMatchers.eq(doctorEmail),
                org.mockito.ArgumentMatchers.eq("Invited Doctor"),
                org.mockito.ArgumentMatchers.eq(invitationToken),
                org.mockito.ArgumentMatchers.any());

        mockMvc.perform(post("/api/auth/invitations/accept")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"token":"%s","password":"DoctorPassword123"}
                                """.formatted(invitationToken)))
                .andExpect(status().isNoContent());

        mockMvc.perform(post("/api/auth/invitations/accept")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"token":"%s","password":"DoctorPassword123"}
                                """.formatted(invitationToken)))
                .andExpect(status().isGone());

        User doctor = userRepository.findByEmail(doctorEmail).orElseThrow();
        assertThat(doctorRepository.findByUser(doctor)).isPresent();
        assertThat(membershipRepository.findAllByUserAndStatus(doctor, MembershipStatus.ACTIVE)).hasSize(1);

        String loginBody = login(doctorEmail, "DoctorPassword123");
        JsonNode login = objectMapper.readTree(loginBody);
        String firstRefreshToken = login.get("refreshToken").asText();
        assertThat(login.get("token").asText()).isNotBlank();

        String refreshBody = mockMvc.perform(post("/api/auth/token/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"refreshToken":"%s"}
                                """.formatted(firstRefreshToken)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.refreshToken").isNotEmpty())
                .andReturn().getResponse().getContentAsString();
        String secondRefreshToken = objectMapper.readTree(refreshBody).get("refreshToken").asText();

        mockMvc.perform(post("/api/auth/token/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"refreshToken":"%s"}
                                """.formatted(firstRefreshToken)))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(post("/api/auth/logout")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"refreshToken":"%s"}
                                """.formatted(secondRefreshToken)))
                .andExpect(status().isNoContent());

        mockMvc.perform(post("/api/auth/token/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"refreshToken":"%s"}
                                """.formatted(secondRefreshToken)))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(post("/api/auth/password/forgot")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email":"%s"}
                                """.formatted(doctorEmail)))
                .andExpect(status().isAccepted());
        ArgumentCaptor<String> resetTokenCaptor = ArgumentCaptor.forClass(String.class);
        verify(emailService).sendPasswordResetToken(org.mockito.ArgumentMatchers.eq(doctorEmail), resetTokenCaptor.capture());

        mockMvc.perform(post("/api/auth/password/reset")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"token":"%s","newPassword":"ChangedPassword123"}
                                """.formatted(resetTokenCaptor.getValue())))
                .andExpect(status().isNoContent());
        assertThat(sessionRepository.findAllByUserAndRevokedAtIsNull(doctor)).isEmpty();
        login(doctorEmail, "ChangedPassword123");

        mockMvc.perform(patch("/api/admin/users/{userId}/account-status", doctor.getUserId())
                        .with(user(admin.getEmail()).roles("ADMIN"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"status":"DISABLED","reason":"Security test"}
                                """))
                .andExpect(status().isNoContent());

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email":"%s","password":"ChangedPassword123"}
                                """.formatted(doctorEmail)))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(get("/api/admin/audit-events")
                        .with(user(admin.getEmail()).roles("ADMIN")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[?(@.action == 'DOCTOR_INVITATION_CREATED')]").exists())
                .andExpect(jsonPath("$.content[?(@.action == 'PASSWORD_RESET')]").exists())
                .andExpect(jsonPath("$.content[?(@.action == 'ACCOUNT_STATUS_CHANGED')]").exists());

        assertThat(secondRefreshToken).isNotEqualTo(firstRefreshToken);
    }

    private String login(String email, String password) throws Exception {
        return mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email":"%s","password":"%s"}
                                """.formatted(email, password)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.refreshToken").isNotEmpty())
                .andReturn().getResponse().getContentAsString();
    }
}
