package ua.nure.holovashenko.medvisionspring.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:admin-bootstrap-test;MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE;DB_CLOSE_DELAY=-1",
        "medvision.bootstrap.admin.enabled=true",
        "medvision.bootstrap.admin.name=Bootstrap Administrator",
        "medvision.bootstrap.admin.email=bootstrap-admin@example.com",
        "medvision.bootstrap.admin.password=StrongPassword123!"
})
@ActiveProfiles("test")
class AdminBootstrapIntegrationTests {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Test
    void applicationStartupCreatesConfiguredAdministrator() {
        User administrator = userRepository.findByEmail("bootstrap-admin@example.com").orElseThrow();

        assertThat(administrator.getUserName()).isEqualTo("Bootstrap Administrator");
        assertThat(administrator.getUserRole()).isEqualTo(UserRole.ADMIN);
        assertThat(passwordEncoder.matches("StrongPassword123!", administrator.getPw())).isTrue();
        assertThat(userRepository.findAll())
                .filteredOn(user -> user.getUserRole() == UserRole.ADMIN)
                .hasSize(1);
    }
}
