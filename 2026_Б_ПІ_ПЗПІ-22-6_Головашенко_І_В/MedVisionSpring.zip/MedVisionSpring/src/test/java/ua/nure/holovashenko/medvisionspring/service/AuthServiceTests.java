package ua.nure.holovashenko.medvisionspring.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.dto.PatientProfileResponse;
import ua.nure.holovashenko.medvisionspring.dto.UserProfileResponse;
import ua.nure.holovashenko.medvisionspring.entity.Patient;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.MembershipStatus;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.repository.DoctorRepository;
import ua.nure.holovashenko.medvisionspring.repository.PatientRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserHospitalMembershipRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.security.JwtService;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTests {

    @Mock
    private UserRepository userRepository;
    @Mock
    private DoctorRepository doctorRepository;
    @Mock
    private PatientRepository patientRepository;
    @Mock
    private UserHospitalMembershipRepository membershipRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private JwtService jwtService;
    @Mock
    private AuthenticationManager authenticationManager;
    @Mock
    private AuthSessionService authSessionService;
    @Mock
    private AuditService auditService;
    @Mock
    private UserDetails userDetails;

    private AuthService service;

    @BeforeEach
    void setUp() {
        service = new AuthService(userRepository, doctorRepository, patientRepository, membershipRepository,
                passwordEncoder, jwtService, authenticationManager, authSessionService,
                new AccountSecurityProperties(5, 15, 30, 48, 30), auditService);
    }

    @Test
    void returnsPatientProfileWhenGenderIsMissing() {
        User user = User.builder()
                .userId(12L)
                .userName("Patient")
                .email("patient@example.com")
                .userRole(UserRole.PATIENT)
                .build();
        Patient patient = Patient.builder()
                .patientId(12L)
                .user(user)
                .gender(null)
                .build();

        when(userDetails.getUsername()).thenReturn("patient@example.com");
        when(userRepository.findByEmail("patient@example.com")).thenReturn(Optional.of(user));
        when(patientRepository.findByUser(user)).thenReturn(Optional.of(patient));
        when(membershipRepository.findAllByUserAndStatus(user, MembershipStatus.ACTIVE)).thenReturn(List.of());

        UserProfileResponse response = service.getProfile(userDetails);

        assertThat(response).isInstanceOf(PatientProfileResponse.class);
        PatientProfileResponse patientProfile = (PatientProfileResponse) response;
        assertThat(patientProfile.getGender()).isNull();
        assertThat(patientProfile.getEmail()).isEqualTo("patient@example.com");
    }
}
