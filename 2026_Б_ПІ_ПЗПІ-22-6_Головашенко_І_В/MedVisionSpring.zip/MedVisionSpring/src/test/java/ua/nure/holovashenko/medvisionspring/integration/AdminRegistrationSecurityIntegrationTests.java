package ua.nure.holovashenko.medvisionspring.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.options;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AdminRegistrationSecurityIntegrationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void anonymousUserCannotRegisterAdministrator() throws Exception {
        mockMvc.perform(post("/api/auth/register/admin")
                .contentType(MediaType.APPLICATION_JSON)
                .content(validRequest()))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error").value("UNAUTHORIZED"))
                .andExpect(jsonPath("$.path").value("/api/auth/register/admin"))
                .andExpect(header().exists("X-Correlation-ID"));
    }

    @Test
    void authenticatedAdministratorCannotUseRemovedRegistrationEndpoint() throws Exception {
        mockMvc.perform(post("/api/auth/register/admin")
                        .with(user("existing-admin@example.com").roles("ADMIN"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validRequest()))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error").value("FORBIDDEN"));
    }

    @Test
    void validCorrelationIdIsReturnedToClient() throws Exception {
        mockMvc.perform(post("/api/auth/register/admin")
                        .header("X-Correlation-ID", "frontend-request-42")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validRequest()))
                .andExpect(status().isUnauthorized())
                .andExpect(header().string("X-Correlation-ID", "frontend-request-42"));
    }

    @Test
    void configuredFrontendOriginPassesCorsPreflight() throws Exception {
        mockMvc.perform(options("/api/auth/login")
                        .header("Origin", "http://localhost:4200")
                        .header("Access-Control-Request-Method", "POST")
                        .header("Access-Control-Request-Headers", "Content-Type,X-Correlation-ID"))
                .andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Origin", "http://localhost:4200"));
    }

    private String validRequest() {
        return """
                {
                  "name": "Unauthorized Admin",
                  "email": "unauthorized-admin@example.com",
                  "password": "StrongPassword123!"
                }
                """;
    }
}
