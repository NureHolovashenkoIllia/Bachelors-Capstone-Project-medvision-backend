package ua.nure.holovashenko.medvisionspring.service;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import ua.nure.holovashenko.medvisionspring.config.StorageSecurityProperties;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;

import java.util.Base64;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FileSecurityServiceTests {

    private static final byte[] PNG_BYTES = Base64.getDecoder().decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
    );

    @Test
    void validatesMagicBytesAndSanitizesOriginalName() {
        FileSecurityService service = new FileSecurityService(new StorageSecurityProperties(1024));
        MockMultipartFile file = new MockMultipartFile("file", "../../patient scan.png", "text/plain", PNG_BYTES);

        FileSecurityService.ValidatedUpload result = service.validate(file);

        assertThat(result.contentType()).isEqualTo("image/png");
        assertThat(result.originalName()).isEqualTo("patient_scan.png");
        assertThat(result.sizeBytes()).isEqualTo(PNG_BYTES.length);
    }

    @Test
    void rejectsDisguisedImage() {
        FileSecurityService service = new FileSecurityService(new StorageSecurityProperties(1024));
        MockMultipartFile file = new MockMultipartFile("file", "scan.png", "image/png", "not-an-image".getBytes());

        assertThatThrownBy(() -> service.validate(file))
                .isInstanceOfSatisfying(ApiException.class,
                        exception -> assertThat(exception.getStatus()).isEqualTo(HttpStatus.UNSUPPORTED_MEDIA_TYPE));
    }

    @Test
    void rejectsFileAboveConfiguredLimit() {
        FileSecurityService service = new FileSecurityService(new StorageSecurityProperties(4));
        MockMultipartFile file = new MockMultipartFile("file", "scan.png", "image/png", PNG_BYTES);

        assertThatThrownBy(() -> service.validate(file))
                .isInstanceOfSatisfying(ApiException.class,
                        exception -> assertThat(exception.getStatus()).isEqualTo(HttpStatus.PAYLOAD_TOO_LARGE));
    }
}
