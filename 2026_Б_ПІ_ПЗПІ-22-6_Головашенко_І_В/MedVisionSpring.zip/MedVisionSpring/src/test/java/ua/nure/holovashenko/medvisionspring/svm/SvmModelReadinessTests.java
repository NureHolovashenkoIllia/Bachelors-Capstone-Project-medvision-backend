package ua.nure.holovashenko.medvisionspring.svm;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ua.nure.holovashenko.medvisionspring.config.SvmRuntimeProperties;
import ua.nure.holovashenko.medvisionspring.enums.SvmRuntimeStatus;
import ua.nure.holovashenko.medvisionspring.exception.SvmModelLoadException;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

class SvmModelReadinessTests {

    @TempDir
    Path tempDirectory;

    @Test
    void missingArtifactsMoveRuntimeToFailedState() {
        SvmModelManager manager = manager(
                tempDirectory.resolve("missing-full.xml"),
                tempDirectory.resolve("missing-patch.xml"),
                1
        );

        assertThrows(SvmModelLoadException.class, manager::loadModels);

        assertEquals(SvmRuntimeStatus.FAILED, manager.getStatus());
        assertFalse(manager.areModelsReady());
    }

    @Test
    void undersizedArtifactsAreRejectedBeforeOpenCvLoad() throws Exception {
        Path fullModel = Files.writeString(tempDirectory.resolve("full.xml"), "invalid");
        Path patchModel = Files.writeString(tempDirectory.resolve("patch.xml"), "invalid");
        SvmModelManager manager = manager(fullModel, patchModel, 1024);

        SvmModelLoadException exception = assertThrows(SvmModelLoadException.class, manager::loadModels);

        assertEquals("SVM model artifact is too small for patch model", exception.getMessage());
        assertEquals(SvmRuntimeStatus.FAILED, manager.getStatus());
    }

    private SvmModelManager manager(Path fullModel, Path patchModel, long minimumArtifactBytes) {
        SvmRuntimeProperties properties = new SvmRuntimeProperties(
                false,
                fullModel.toString(),
                patchModel.toString(),
                "",
                "",
                minimumArtifactBytes
        );
        return new SvmModelManager(
                mock(ImagePatchExtractor.class),
                mock(MetricsCalculator.class),
                properties
        );
    }
}
