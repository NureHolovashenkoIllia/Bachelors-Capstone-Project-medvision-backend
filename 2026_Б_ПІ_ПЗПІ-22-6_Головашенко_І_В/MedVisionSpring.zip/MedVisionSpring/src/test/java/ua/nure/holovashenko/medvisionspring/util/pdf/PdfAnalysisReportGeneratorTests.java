package ua.nure.holovashenko.medvisionspring.util.pdf;

import org.junit.jupiter.api.Test;
import ua.nure.holovashenko.medvisionspring.entity.ImageAnalysis;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

class PdfAnalysisReportGeneratorTests {

    @Test
    void generateAnalysisPdfCreatesDocumentWhenHeatmapIsUnavailable() throws Exception {
        User patient = User.builder()
                .userId(1L)
                .userName("Test Patient")
                .email("patient@example.com")
                .pw("password")
                .userRole(UserRole.PATIENT)
                .build();
        User doctor = User.builder()
                .userId(2L)
                .userName("Test Doctor")
                .email("doctor@example.com")
                .pw("password")
                .userRole(UserRole.DOCTOR)
                .build();
        ImageAnalysis analysis = ImageAnalysis.builder()
                .imageAnalysisId(12L)
                .analysisDetails("Test analysis details")
                .analysisDiagnosis("Test diagnosis")
                .treatmentRecommendations("Test recommendations")
                .analysisAccuracy(0.95f)
                .analysisPrecision(0.94f)
                .analysisRecall(0.93f)
                .creationDatetime(LocalDateTime.of(2026, 6, 26, 21, 3))
                .patient(patient)
                .doctor(doctor)
                .build();

        byte[] pdf = PdfAnalysisReportGenerator.generateAnalysisPdf(analysis, Optional.empty());

        assertThat(pdf).startsWith("%PDF".getBytes());
        assertThat(pdf.length).isGreaterThan(1000);
    }
}
