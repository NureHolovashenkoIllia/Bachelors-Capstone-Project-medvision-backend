package ua.nure.holovashenko.medvisionspring.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ua.nure.holovashenko.medvisionspring.entity.ImageFile;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;
import ua.nure.holovashenko.medvisionspring.svm.ImagePatchExtractor;
import ua.nure.holovashenko.medvisionspring.svm.MetricsCalculator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SvmExperimentExecutionServiceTests {

    @Test
    void readImageFileUsesStorageKeyBeforeApiUrl() throws Exception {
        BlobStorageService storage = mock(BlobStorageService.class);
        byte[] expected = new byte[]{1, 2, 3};
        when(storage.downloadFileByName("demo/sample.png")).thenReturn(expected);

        SvmExperimentExecutionService service = service(storage);
        byte[] actual = service.readImageFile(ImageFile.builder()
                .imageFileUrl("/api/files/demo/sample.png")
                .storageKey("demo/sample.png")
                .imageFileType("image/png")
                .build());

        assertThat(actual).isEqualTo(expected);
        verify(storage).downloadFileByName("demo/sample.png");
        verify(storage, never()).downloadFileFromBlobUrl("/api/files/demo/sample.png");
    }

    @Test
    void readImageFileFallsBackToBlobUrlWhenStorageKeyIsMissing() throws Exception {
        BlobStorageService storage = mock(BlobStorageService.class);
        byte[] expected = new byte[]{4, 5, 6};
        String url = "file:///tmp/sample.png";
        when(storage.downloadFileFromBlobUrl(url)).thenReturn(expected);

        SvmExperimentExecutionService service = service(storage);
        byte[] actual = service.readImageFile(ImageFile.builder()
                .imageFileUrl(url)
                .imageFileType("image/png")
                .build());

        assertThat(actual).isEqualTo(expected);
        verify(storage).downloadFileFromBlobUrl(url);
    }

    private SvmExperimentExecutionService service(BlobStorageService storage) {
        return new SvmExperimentExecutionService(
                null,
                null,
                null,
                null,
                storage,
                mock(ImagePatchExtractor.class),
                mock(MetricsCalculator.class),
                new ObjectMapper()
        );
    }
}
