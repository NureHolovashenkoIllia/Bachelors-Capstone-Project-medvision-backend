package ua.nure.holovashenko.medvisionspring.util.email;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import ua.nure.holovashenko.medvisionspring.config.FrontendProperties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class EmailServiceTests {

    @Mock
    private JavaMailSender mailSender;

    @Test
    void passwordResetEmailContainsFrontendResetLink() {
        EmailService service = new EmailService(mailSender,
                new FrontendProperties("http://localhost:4200/reset-password", "http://localhost:4200/accept-invitation"));

        service.sendPasswordResetToken("patient@example.com", "w0vzEX3ZM917qiApIz3rGXqmp7Gzd1pGebhV3VBy7nY");

        ArgumentCaptor<SimpleMailMessage> messageCaptor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(messageCaptor.capture());
        SimpleMailMessage message = messageCaptor.getValue();
        assertThat(message.getTo()).containsExactly("patient@example.com");
        assertThat(message.getSubject()).isEqualTo("MedVision password reset");
        assertThat(message.getText()).contains("http://localhost:4200/reset-password?token=w0vzEX3ZM917qiApIz3rGXqmp7Gzd1pGebhV3VBy7nY");
    }

    @Test
    void doctorInvitationEmailContainsFrontendInvitationLink() {
        EmailService service = new EmailService(mailSender,
                new FrontendProperties("http://localhost:4200/reset-password", "http://localhost:4200/accept-invitation"));

        service.sendDoctorInvitation("doctor@example.com", "Dr Katya", "Sues_CNm70a6TGLZie2ZPrT2mE4iSS6VuE9HXD", java.time.LocalDateTime.parse("2026-06-26T19:37:59"));

        ArgumentCaptor<SimpleMailMessage> messageCaptor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(messageCaptor.capture());
        SimpleMailMessage message = messageCaptor.getValue();
        assertThat(message.getTo()).containsExactly("doctor@example.com");
        assertThat(message.getSubject()).isEqualTo("MedVision doctor invitation");
        assertThat(message.getText()).contains("http://localhost:4200/accept-invitation?token=Sues_CNm70a6TGLZie2ZPrT2mE4iSS6VuE9HXD");
    }
}
