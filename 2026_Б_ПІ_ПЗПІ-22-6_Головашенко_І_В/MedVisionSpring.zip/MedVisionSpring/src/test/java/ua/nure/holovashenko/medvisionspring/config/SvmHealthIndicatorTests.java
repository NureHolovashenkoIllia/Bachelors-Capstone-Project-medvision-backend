package ua.nure.holovashenko.medvisionspring.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Status;
import ua.nure.holovashenko.medvisionspring.enums.SvmRuntimeStatus;
import ua.nure.holovashenko.medvisionspring.svm.SvmModelManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SvmHealthIndicatorTests {

    private final SvmModelManager modelManager = mock(SvmModelManager.class);
    private final SvmHealthIndicator indicator = new SvmHealthIndicator(modelManager);

    @Test
    void readyModelReportsUp() {
        when(modelManager.getStatus()).thenReturn(SvmRuntimeStatus.READY);

        assertEquals(Status.UP, indicator.health().getStatus());
    }

    @Test
    void failedModelReportsDown() {
        when(modelManager.getStatus()).thenReturn(SvmRuntimeStatus.FAILED);

        assertEquals(Status.DOWN, indicator.health().getStatus());
    }

    @Test
    void loadingModelReportsOutOfService() {
        when(modelManager.getStatus()).thenReturn(SvmRuntimeStatus.LOADING);

        assertEquals(new Status("OUT_OF_SERVICE"), indicator.health().getStatus());
    }
}
