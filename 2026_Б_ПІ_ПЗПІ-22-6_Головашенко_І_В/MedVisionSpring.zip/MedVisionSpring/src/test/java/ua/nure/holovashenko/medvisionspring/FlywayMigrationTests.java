package ua.nure.holovashenko.medvisionspring;

import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.MigrationVersion;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class FlywayMigrationTests {

    @Autowired
    private Flyway flyway;

    @Test
    void appliesBaselineMigration() {
        assertThat(flyway.info().applied()).isNotEmpty();
        assertThat(flyway.info().current().getVersion().getVersion()).isEqualTo("13");
    }

    @Test
    void upgradesVersionNineSchemaToVersionThirteen() {
        String url = "jdbc:h2:mem:upgrade_v9;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1";
        Flyway versionNine = Flyway.configure().dataSource(url, "sa", "").locations("classpath:db/migration")
                .target(MigrationVersion.fromVersion("9")).load();
        versionNine.migrate();
        assertThat(versionNine.info().current().getVersion().getVersion()).isEqualTo("9");
        Flyway upgraded = Flyway.configure().dataSource(url, "sa", "").locations("classpath:db/migration").load();
        upgraded.migrate();
        assertThat(upgraded.info().current().getVersion().getVersion()).isEqualTo("13");
    }
}
