package ua.nure.holovashenko.medvisionspring.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.dto.AuthResponse;
import ua.nure.holovashenko.medvisionspring.entity.AuthSession;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.AuthSessionRepository;
import ua.nure.holovashenko.medvisionspring.security.JwtService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthSessionServiceTests {

    @Mock
    private AuthSessionRepository repository;
    @Mock
    private SecureTokenService tokenService;
    @Mock
    private JwtService jwtService;
    @Mock
    private AuditService auditService;

    private AuthSessionService service;

    @BeforeEach
    void setUp() {
        service = new AuthSessionService(repository, tokenService, jwtService,
                new AccountSecurityProperties(5, 15, 30, 24, 30), auditService);
    }

    @Test
    void rotatesRefreshTokenAndRevokesPreviousSession() {
        User user = User.builder().userId(7L).email("doctor@example.com")
                .accountStatus(UserAccountStatus.ACTIVE).build();
        AuthSession oldSession = AuthSession.builder().authSessionId(3L).user(user).tokenHash("old-hash")
                .createdAt(LocalDateTime.now()).expiresAt(LocalDateTime.now().plusDays(1)).build();
        when(tokenService.hash("old-token")).thenReturn("old-hash");
        when(repository.findByTokenHash("old-hash")).thenReturn(Optional.of(oldSession));
        when(tokenService.generate()).thenReturn("new-token");
        when(tokenService.hash("new-token")).thenReturn("new-hash");
        when(jwtService.generateToken(user)).thenReturn("access-token");
        when(jwtService.getExpirationSeconds()).thenReturn(900L);
        when(repository.save(any(AuthSession.class))).thenAnswer(invocation -> invocation.getArgument(0));

        AuthResponse response = service.rotate("old-token", "browser", "127.0.0.1");

        assertThat(oldSession.getRevokedAt()).isNotNull();
        assertThat(response.getToken()).isEqualTo("access-token");
        assertThat(response.getRefreshToken()).isEqualTo("new-token");
        assertThat(response.getExpiresInSeconds()).isEqualTo(900);
    }

    @Test
    void rejectsExpiredRefreshToken() {
        User user = User.builder().userId(7L).accountStatus(UserAccountStatus.ACTIVE).build();
        AuthSession session = AuthSession.builder().user(user).tokenHash("hash")
                .createdAt(LocalDateTime.now().minusDays(2)).expiresAt(LocalDateTime.now().minusMinutes(1)).build();
        when(tokenService.hash("expired")).thenReturn("hash");
        when(repository.findByTokenHash("hash")).thenReturn(Optional.of(session));

        assertThatThrownBy(() -> service.rotate("expired", null, null)).isInstanceOf(ApiException.class);
    }

    @Test
    void revokesAllActiveSessions() {
        User user = User.builder().userId(7L).build();
        AuthSession first = AuthSession.builder().user(user).build();
        AuthSession second = AuthSession.builder().user(user).build();
        when(repository.findAllByUserAndRevokedAtIsNull(user)).thenReturn(List.of(first, second));

        service.revokeAll(user);

        assertThat(first.getRevokedAt()).isNotNull();
        assertThat(second.getRevokedAt()).isNotNull();
        verify(repository).findAllByUserAndRevokedAtIsNull(user);
    }

    @Test
    void revokesSingleSessionByRefreshTokenWithoutPrincipal() {
        User user = User.builder().userId(7L).build();
        AuthSession session = AuthSession.builder().user(user).tokenHash("hash").build();
        when(tokenService.hash("refresh-token")).thenReturn("hash");
        when(repository.findByTokenHash("hash")).thenReturn(Optional.of(session));

        service.revoke("refresh-token");

        assertThat(session.getRevokedAt()).isNotNull();
        verify(repository).save(session);
    }
}
