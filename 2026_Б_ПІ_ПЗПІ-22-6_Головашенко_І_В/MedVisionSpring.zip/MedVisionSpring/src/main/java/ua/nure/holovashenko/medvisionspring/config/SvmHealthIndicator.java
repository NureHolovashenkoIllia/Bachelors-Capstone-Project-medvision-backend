package ua.nure.holovashenko.medvisionspring.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import ua.nure.holovashenko.medvisionspring.svm.SvmModelManager;

@Component("svm")
@RequiredArgsConstructor
public class SvmHealthIndicator implements HealthIndicator {

    private final SvmModelManager modelManager;

    @Override
    public Health health() {
        return switch (modelManager.getStatus()) {
            case READY -> Health.up().withDetail("status", "READY").build();
            case FAILED -> Health.down().withDetail("status", "FAILED").build();
            case LOADING -> Health.status("OUT_OF_SERVICE").withDetail("status", "LOADING").build();
            case NOT_LOADED -> Health.unknown().withDetail("status", "NOT_LOADED").build();
        };
    }
}
