package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.AnalysisReview;
import ua.nure.holovashenko.medvisionspring.entity.ImageAnalysis;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisReviewDecision;

import java.util.Optional;

public interface AnalysisReviewRepository extends JpaRepository<AnalysisReview, Long> {
    Optional<AnalysisReview> findByImageAnalysis(ImageAnalysis imageAnalysis);
    Page<AnalysisReview> findAllByDecision(AnalysisReviewDecision decision, Pageable pageable);
}
