package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.SvmArtifactType;

import java.time.LocalDateTime;

@Entity
@Table(name = "svm_experiment_artifact")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SvmExperimentArtifact {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "experiment_artifact_id")
    private Long experimentArtifactId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "experiment_id", nullable = false)
    private SvmExperiment experiment;

    @Enumerated(EnumType.STRING)
    @Column(name = "artifact_type", nullable = false, length = 32)
    private SvmArtifactType artifactType;

    @Column(name = "storage_uri", nullable = false, length = 1000)
    private String storageUri;

    @Column(name = "checksum_sha256", nullable = false, length = 64)
    private String checksumSha256;

    @Column(name = "size_bytes", nullable = false)
    private Long sizeBytes;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
