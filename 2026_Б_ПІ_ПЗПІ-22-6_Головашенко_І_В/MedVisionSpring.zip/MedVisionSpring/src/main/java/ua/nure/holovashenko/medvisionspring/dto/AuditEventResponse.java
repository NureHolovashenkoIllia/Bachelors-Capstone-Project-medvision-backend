package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.AuditOutcome;
import java.time.LocalDateTime;

public record AuditEventResponse(Long id, Long actorId, Long hospitalId, String action,
                                 String resourceType, String resourceId, AuditOutcome outcome,
                                 String correlationId, String metadata, LocalDateTime occurredAt) {
}
