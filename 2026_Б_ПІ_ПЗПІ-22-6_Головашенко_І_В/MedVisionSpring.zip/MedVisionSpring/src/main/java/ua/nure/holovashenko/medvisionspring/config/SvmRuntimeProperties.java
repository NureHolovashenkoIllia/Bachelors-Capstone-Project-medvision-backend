package ua.nure.holovashenko.medvisionspring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "medvision.svm")
public record SvmRuntimeProperties(
        boolean preloadEnabled,
        String fullModelPath,
        String patchModelPath,
        String fullModelChecksum,
        String patchModelChecksum,
        long minimumArtifactBytes
) {
}
