package ua.nure.holovashenko.medvisionspring.enums;

public enum AccountTokenPurpose {
    DOCTOR_INVITATION,
    EMAIL_VERIFICATION,
    PASSWORD_RESET
}
