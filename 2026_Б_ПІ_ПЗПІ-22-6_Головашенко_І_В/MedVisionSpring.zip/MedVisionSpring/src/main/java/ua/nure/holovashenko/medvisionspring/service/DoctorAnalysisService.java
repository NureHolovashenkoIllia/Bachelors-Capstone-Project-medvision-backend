package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.multipart.MultipartFile;
import ua.nure.holovashenko.medvisionspring.dto.AddNoteRequest;
import ua.nure.holovashenko.medvisionspring.dto.ImageAnalysisResponse;
import ua.nure.holovashenko.medvisionspring.dto.AnalysisJobResponse;
import ua.nure.holovashenko.medvisionspring.dto.PatientProfileResponse;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;
import ua.nure.holovashenko.medvisionspring.svm.ImageUtils;
import ua.nure.holovashenko.medvisionspring.svm.MetricsCalculator;
import ua.nure.holovashenko.medvisionspring.svm.SvmClassificationRequest;
import ua.nure.holovashenko.medvisionspring.svm.SvmClassificationResult;
import ua.nure.holovashenko.medvisionspring.svm.SvmClient;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
@Slf4j
public class DoctorAnalysisService {

    private final SvmClient svmClient;
    private final ImageUtils imageUtils;
    private final BlobStorageService blobStorageService;
    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final ImageAnalysisRepository imageAnalysisRepository;
    private final DiagnosisHistoryRepository diagnosisHistoryRepository;
    private final ImageFileRepository imageFileRepository;
    private final AnalysisNoteRepository analysisNoteRepository;
    private final LegacyTreatmentResolver legacyTreatmentResolver;
    private final TreatmentService treatmentService;
    private final AnalysisJobService analysisJobService;
    private final SvmModelRegistryService svmModelRegistryService;
    private final TransactionTemplate transactionTemplate;
    private final TreatmentRepository treatmentRepository;
    private final AnalysisService analysisService;
    private final FileSecurityService fileSecurityService;

    public ImageAnalysis analyzeAndSave(MultipartFile file, Long patientId, Long doctorId) throws IOException {
        User patientUser = userRepository.findById(patientId)
                .orElseThrow(() -> new ApiException("Пацієнт не знайдений", HttpStatus.NOT_FOUND));
        User doctorUser = userRepository.findById(doctorId)
                .orElseThrow(() -> new ApiException("Лікар не знайдений", HttpStatus.NOT_FOUND));

        Treatment treatment = legacyTreatmentResolver.resolve(patientUser, doctorUser);
        return analyzeAndSave(file, treatment, doctorUser);
    }

    public ImageAnalysis analyzeAndSave(MultipartFile file, Long hospitalId, Long treatmentId, UserDetails userDetails) throws IOException {
        User doctorUser = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ApiException("Лікар не знайдений", HttpStatus.NOT_FOUND));
        Treatment treatment = treatmentService.getTreatmentForAnalysis(hospitalId, treatmentId, userDetails);
        return analyzeAndSave(file, treatment, doctorUser);
    }

    public AnalysisJobResponse submit(MultipartFile file, Long hospitalId, Long treatmentId, Long modelId, UserDetails principal) throws IOException {
        User doctor = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("Лікар не знайдений", HttpStatus.NOT_FOUND));
        Treatment treatment = treatmentService.getTreatmentForAnalysis(hospitalId, treatmentId, principal);
        SvmModelVersion model = svmModelRegistryService.resolveFullImageModel(modelId);
        FileSecurityService.ValidatedUpload upload = fileSecurityService.validate(file);
        File temporary = File.createTempFile("queued-analysis-", extensionFor(upload.contentType()));
        String storageKey = "analysis-input/" + UUID.randomUUID() + extensionFor(upload.contentType());
        try {
            file.transferTo(temporary);
            String url = blobStorageService.uploadFile(temporary, storageKey, upload.contentType());
            FileSecurityService.StoredMetadata metadata = fileSecurityService.metadata(temporary, storageKey, upload.originalName(), upload.contentType());
            AnalysisJob job = transactionTemplate.execute(status -> {
                ImageFile input = imageFileRepository.save(ImageFile.builder().imageFileName(storageKey).imageFileType(upload.contentType())
                        .uploadedAt(LocalDateTime.now()).imageFileUrl(url).storageKey(storageKey).originalFileName(upload.originalName())
                        .sizeBytes(metadata.sizeBytes()).checksumSha256(metadata.checksumSha256()).contentTypeVerified(true)
                        .uploadedBy(doctor).hospital(treatment.getHospital()).treatment(treatment).build());
                return analysisJobService.createPendingJob(treatment.getHospital(), treatment, doctor, input, model,
                        "fileName=" + upload.originalName() + ";contentType=" + upload.contentType() + ";modelId=" + model.getModelVersionId());
            });
            return analysisJobService.mapToResponse(job);
        } catch (Exception exception) {
            cleanupUploadedFile(storageKey);
            if (exception instanceof IOException ioException) throw ioException;
            if (exception instanceof RuntimeException runtimeException) throw runtimeException;
            throw new IOException(exception);
        } finally {
            temporary.delete();
        }
    }

    public void processQueuedJob(Long jobId) {
        AnalysisJob job = analysisJobService.getForWorker(jobId);
        File image = null;
        File model = null;
        File heatmap = null;
        String heatmapKey = null;
        try {
            image = File.createTempFile("analysis-input-", extensionFor(job.getInputFile().getImageFileType()));
            Files.write(image.toPath(), downloadArtifact(job.getInputFile().getImageFileUrl()));
            if (job.getModelVersion().getArtifactChecksum() != null) {
                model = File.createTempFile("svm-model-", ".xml");
                byte[] modelBytes = downloadArtifact(job.getModelVersion().getStorageUri());
                verifyModelArtifact(job.getModelVersion(), modelBytes);
                Files.write(model.toPath(), modelBytes);
            }
            SvmClassificationResult classification = svmClient.classify(new SvmClassificationRequest(image, true, model,
                    svmModelRegistryService.runtimeMetrics(job.getModelVersion())));
            heatmap = File.createTempFile("heatmap-", ".png");
            imageUtils.saveMatToFile(classification.heatmap(), heatmap);
            heatmapKey = "heatmaps/" + UUID.randomUUID() + ".png";
            String heatmapUrl = blobStorageService.uploadFile(heatmap, heatmapKey, "image/png");
            FileSecurityService.StoredMetadata heatmapMetadata = fileSecurityService.metadata(heatmap, heatmapKey, "heatmap.png", "image/png");
            saveCompletedAnalysis(job.getTreatment().getTreatmentId(), job.getRequestedBy().getUserId(), job, classification,
                    job.getModelVersion(), job.getInputFile(), null, null, null, heatmapKey, heatmapUrl, heatmapMetadata);
        } catch (Exception exception) {
            cleanupUploadedFile(heatmapKey);
            analysisJobService.failJob(job, exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage());
        } finally {
            if (image != null) image.delete();
            if (model != null) model.delete();
            if (heatmap != null) heatmap.delete();
        }
    }

    private ImageAnalysis analyzeAndSave(MultipartFile file, Treatment treatment, User doctorUser) throws IOException {
        FileSecurityService.ValidatedUpload validatedUpload = fileSecurityService.validate(file);
        String contentType = validatedUpload.contentType();
        String safeFileName = validatedUpload.originalName();
        AnalysisJob job = analysisJobService.createProcessingJob(
                treatment.getHospital(),
                treatment,
                doctorUser,
                "fileName=" + safeFileName + ";contentType=" + contentType
        );
        File tempFile = File.createTempFile("upload-", ".png");
        File heatmapFile = null;
        String imageObjectName = null;
        String heatmapObjectName = null;
        try {
            file.transferTo(tempFile);

            SvmClassificationResult classification = svmClient.classify(new SvmClassificationRequest(tempFile, true));
            SvmModelVersion modelVersion = svmModelRegistryService.getActiveFullImageModel();

            imageObjectName = "images/" + UUID.randomUUID() + extensionFor(contentType);
            String imageUrl = blobStorageService.uploadFile(tempFile, imageObjectName, contentType);
            FileSecurityService.StoredMetadata imageMetadata = fileSecurityService.metadata(
                    tempFile, imageObjectName, validatedUpload.originalName(), contentType);

            heatmapFile = File.createTempFile("heatmap-", ".png");
            imageUtils.saveMatToFile(classification.heatmap(), heatmapFile);

            heatmapObjectName = "heatmaps/" + UUID.randomUUID() + ".png";
            String heatmapUrl = blobStorageService.uploadFile(heatmapFile, heatmapObjectName, "image/png");
            FileSecurityService.StoredMetadata heatmapMetadata = fileSecurityService.metadata(
                    heatmapFile, heatmapObjectName, "heatmap.png", "image/png");

            return saveCompletedAnalysis(
                    treatment.getTreatmentId(),
                    doctorUser.getUserId(),
                    job,
                    classification,
                    modelVersion,
                    null,
                    imageObjectName,
                    imageUrl,
                    imageMetadata,
                    heatmapObjectName,
                    heatmapUrl,
                    heatmapMetadata
            );
        } catch (Exception e) {
            cleanupUploadedFile(imageObjectName);
            cleanupUploadedFile(heatmapObjectName);
            try {
                analysisJobService.failJob(job, e.getMessage());
            } catch (Exception jobFailureException) {
                log.error("Failed to mark analysis job {} as FAILED", job.getAnalysisJobId(), jobFailureException);
            }
            if (e instanceof IOException ioException) {
                throw ioException;
            }
            if (e instanceof RuntimeException runtimeException) {
                throw runtimeException;
            }
            throw new RuntimeException(e);
        } finally {
            tempFile.delete();
            if (heatmapFile != null) {
                heatmapFile.delete();
            }
        }
    }

    private ImageAnalysis saveCompletedAnalysis(
            Long treatmentId,
            Long doctorUserId,
            AnalysisJob job,
            SvmClassificationResult classification,
            SvmModelVersion modelVersion,
            ImageFile existingImageFile,
            String imageObjectName,
            String imageUrl,
            FileSecurityService.StoredMetadata imageMetadata,
            String heatmapObjectName,
            String heatmapUrl,
            FileSecurityService.StoredMetadata heatmapMetadata
    ) {
        return transactionTemplate.execute(status -> {
            Treatment managedTreatment = treatmentRepository.findById(treatmentId)
                    .orElseThrow(() -> new ApiException("Лікування не знайдено", HttpStatus.NOT_FOUND));
            User managedDoctorUser = userRepository.findById(doctorUserId)
                    .orElseThrow(() -> new ApiException("Лікар не знайдений", HttpStatus.NOT_FOUND));
            User patientUser = managedTreatment.getPatient();
            Hospital hospital = managedTreatment.getHospital();

            ImageFile imageFile = existingImageFile != null ? imageFileRepository.findById(existingImageFile.getImageFileId())
                    .orElseThrow(() -> new ApiException("Input image not found", HttpStatus.NOT_FOUND)) : ImageFile.builder()
                    .imageFileName(imageObjectName)
                    .imageFileType(imageMetadata.contentType())
                    .uploadedAt(LocalDateTime.now())
                    .imageFileUrl(imageUrl)
                    .storageKey(imageMetadata.storageKey())
                    .originalFileName(imageMetadata.originalName())
                    .sizeBytes(imageMetadata.sizeBytes())
                    .checksumSha256(imageMetadata.checksumSha256())
                    .contentTypeVerified(true)
                    .uploadedBy(managedDoctorUser)
                    .hospital(hospital)
                    .treatment(managedTreatment)
                    .build();
            if (existingImageFile == null) imageFileRepository.save(imageFile);

            ImageFile heatmapImage = ImageFile.builder()
                    .imageFileName(heatmapObjectName)
                    .imageFileType(heatmapMetadata.contentType())
                    .uploadedAt(LocalDateTime.now())
                    .imageFileUrl(heatmapUrl)
                    .storageKey(heatmapMetadata.storageKey())
                    .originalFileName(heatmapMetadata.originalName())
                    .sizeBytes(heatmapMetadata.sizeBytes())
                    .checksumSha256(heatmapMetadata.checksumSha256())
                    .contentTypeVerified(true)
                    .uploadedBy(managedDoctorUser)
                    .hospital(hospital)
                    .treatment(managedTreatment)
                    .build();
            imageFileRepository.save(heatmapImage);

            MetricsCalculator.ClassMetrics classMetrics = classification.classMetrics();
            float precision = classMetrics != null ? (float) classMetrics.precision() : 0f;
            float recall = classMetrics != null ? (float) classMetrics.recall() : 0f;

            ImageAnalysis analysis = ImageAnalysis.builder()
                    .imageFile(imageFile)
                    .heatmapFile(heatmapImage)
                    .analysisDetails(classification.diagnosisInfo().getAnalysisDetails())
                    .analysisDiagnosis(classification.diagnosisInfo().getAnalysisDiagnosis())
                    .treatmentRecommendations(classification.diagnosisInfo().getTreatmentRecommendations())
                    .analysisAccuracy((float) classification.metrics().accuracy())
                    .analysisPrecision(precision)
                    .analysisRecall(recall)
                    .creationDatetime(LocalDateTime.now())
                    .analysisStatus(AnalysisStatus.REQUIRES_REVISION)
                    .diagnosisClass(classification.diagnosisClass())
                    .patient(patientUser)
                    .doctor(managedDoctorUser)
                    .hospital(hospital)
                    .treatment(managedTreatment)
                    .analysisJob(job)
                    .modelVersion(modelVersion)
                    .build();

            ImageAnalysis savedAnalysis = imageAnalysisRepository.save(analysis);

            Doctor doctor = doctorRepository.findById(managedDoctorUser.getUserId()).orElse(null);

            DiagnosisHistory diagnosis = DiagnosisHistory.builder()
                    .imageAnalysis(savedAnalysis)
                    .diagnosisText(savedAnalysis.getAnalysisDiagnosis())
                    .changedByDoctor(doctor)
                    .changeReason("Діагноз SVM")
                    .build();

            diagnosisHistoryRepository.save(diagnosis);

            Patient patient = patientRepository.findById(patientUser.getUserId())
                    .orElseThrow(() -> new ApiException("Пацієнт не знайдений", HttpStatus.NOT_FOUND));

            patient.setLastExamDate(LocalDate.now());
            patientRepository.save(patient);

            analysisJobService.completeJob(
                    job,
                    savedAnalysis,
                    "diagnosisClass=" + savedAnalysis.getDiagnosisClass()
                            + ";analysisId=" + savedAnalysis.getImageAnalysisId()
            );

            return savedAnalysis;
        });
    }

    private String extensionFor(String contentType) {
        return "image/jpeg".equals(contentType) ? ".jpg" : ".png";
    }

    private byte[] downloadArtifact(String location) throws IOException {
        return location.contains("://") || location.startsWith("file:")
                ? blobStorageService.downloadFileFromBlobUrl(location)
                : blobStorageService.downloadFileByName(location);
    }

    private void verifyModelArtifact(SvmModelVersion modelVersion, byte[] data) throws Exception {
        if (modelVersion.getArtifactSizeBytes() != null && modelVersion.getArtifactSizeBytes() != data.length) {
            throw new IllegalStateException("Model artifact size mismatch");
        }
        String checksum = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        if (modelVersion.getArtifactChecksum() != null && !modelVersion.getArtifactChecksum().equalsIgnoreCase(checksum)) {
            throw new IllegalStateException("Model artifact checksum mismatch");
        }
    }

    private void cleanupUploadedFile(String storageKey) {
        if (storageKey == null) {
            return;
        }
        try {
            blobStorageService.deleteFile(storageKey);
        } catch (Exception cleanupError) {
            log.error("Failed to compensate uploaded object {}", storageKey, cleanupError);
        }
    }

    public Optional<ImageAnalysis> getAnalysis(Long id) {
        return imageAnalysisRepository.findById(id);
    }

    public Optional<ImageAnalysisResponse> getAnalysisResponse(Long id) {
        return imageAnalysisRepository.findById(id).map(analysisService::mapToDto);
    }

    public Optional<byte[]> getHeatmapBytes(Long id) throws IOException {
        return imageAnalysisRepository.findById(id).map(a -> {
            try {
                return blobStorageService.downloadFileFromBlobUrl(a.getHeatmapFile().getImageFileUrl());
            } catch (IOException e) {
                throw new RuntimeException("Cannot read heatmap from Azure Blob Storage", e);
            }
        });
    }

    public boolean updateDiagnosis(Long id, String diagnosis) {
        return imageAnalysisRepository.findById(id).map(a -> {
            a.setAnalysisDiagnosis(diagnosis);
            imageAnalysisRepository.save(a);
            return true;
        }).orElse(false);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public List<PatientProfileResponse> getAllPatientProfiles() {
        return patientRepository.findAll().stream()
                .map(this::mapPatientProfile)
                .toList();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));
    }

    public PatientProfileResponse getPatientProfileById(Long id) {
        return patientRepository.findById(id)
                .map(this::mapPatientProfile)
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));
    }

    private PatientProfileResponse mapPatientProfile(Patient patient) {
        User user = patient.getUser();
        return PatientProfileResponse.builder()
                .id(patient.getPatientId())
                .name(user != null ? user.getUserName() : null)
                .email(user != null ? user.getEmail() : null)
                .role(user != null ? user.getUserRole() : null)
                .birthDate(patient.getBirthDate())
                .gender(patient.getGender() != null ? patient.getGender().name() : null)
                .heightCm(patient.getHeightCm())
                .weightKg(patient.getWeightKg())
                .chronicDiseases(patient.getChronicDiseases())
                .allergies(patient.getAllergies())
                .address(patient.getAddress())
                .lastExamDate(patient.getLastExamDate())
                .hospitals(List.of())
                .build();
    }

    @Transactional
    public boolean addNote(Long analysesId, Long doctorId, AddNoteRequest inputNote) {
        try {
            ImageAnalysis analysis = imageAnalysisRepository.findById(analysesId)
                    .orElseThrow(() -> new IllegalArgumentException("Image analysis not found"));
            Doctor doctor = doctorRepository.findById(doctorId)
                    .orElseThrow(() -> new IllegalArgumentException("Doctor not found"));

            AnalysisNote note = AnalysisNote.builder()
                    .noteText(inputNote.getNoteText())
                    .noteAreaX(inputNote.getNoteAreaX())
                    .noteAreaY(inputNote.getNoteAreaY())
                    .noteAreaWidth(inputNote.getNoteAreaWidth())
                    .noteAreaHeight(inputNote.getNoteAreaHeight())
                    .creationDatetime(LocalDateTime.now())
                    .doctor(doctor)
                    .imageAnalysis(analysis)
                    .build();

            analysisNoteRepository.save(note);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
