package ua.nure.holovashenko.medvisionspring.dto;

import java.util.Map;

public record DatasetSplitResponse(
        Long datasetId,
        Long seed,
        Map<String, Long> counts,
        Map<String, Map<Integer, Long>> classDistribution
) {}
