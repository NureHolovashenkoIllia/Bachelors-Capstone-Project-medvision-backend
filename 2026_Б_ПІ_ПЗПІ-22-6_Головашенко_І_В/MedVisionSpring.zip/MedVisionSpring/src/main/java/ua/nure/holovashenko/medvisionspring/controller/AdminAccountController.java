package ua.nure.holovashenko.medvisionspring.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.service.AccountLifecycleService;
import ua.nure.holovashenko.medvisionspring.service.InvitationService;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminAccountController {
    private final InvitationService invitationService;
    private final AccountLifecycleService accountLifecycleService;
    private final UserRepository userRepository;

    @PostMapping("/invitations/doctors")
    public ResponseEntity<DoctorInvitationResponse> inviteDoctor(
            @Valid @RequestBody DoctorInvitationRequest request,
            @AuthenticationPrincipal UserDetails principal) {
        return ResponseEntity.status(HttpStatus.CREATED).body(invitationService.invite(request, principal));
    }

    @PatchMapping("/users/{userId}/account-status")
    public ResponseEntity<Void> updateAccountStatus(@PathVariable Long userId,
                                                     @Valid @RequestBody AccountStatusRequest request,
                                                     @AuthenticationPrincipal UserDetails principal) {
        var actor = userRepository.findByEmail(principal.getUsername()).orElseThrow();
        accountLifecycleService.updateStatus(actor, userId, request);
        return ResponseEntity.noContent().build();
    }
}
