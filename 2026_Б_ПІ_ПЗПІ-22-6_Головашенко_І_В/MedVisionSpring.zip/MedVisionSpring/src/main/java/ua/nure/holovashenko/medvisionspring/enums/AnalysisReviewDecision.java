package ua.nure.holovashenko.medvisionspring.enums;

public enum AnalysisReviewDecision {
    CONFIRMED,
    CORRECTED,
    REJECTED
}
