package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnalysisReviewService {
    private final AnalysisReviewRepository reviewRepository;
    private final AnalysisClassScoreRepository scoreRepository;
    private final ImageAnalysisRepository analysisRepository;
    private final UserRepository userRepository;
    private final ResearchDatasetService datasetService;
    private final DatasetItemRepository datasetItemRepository;
    private final TreatmentService treatmentService;
    private final HospitalAccessPolicy accessPolicy;

    @Transactional
    public AnalysisReviewResponse review(Long hospitalId, Long treatmentId, Long analysisId, AnalysisReviewRequest request, UserDetails principal) {
        ImageAnalysis analysis = requireAnalysis(hospitalId, treatmentId, analysisId, principal);
        if (request.decision() == AnalysisReviewDecision.CORRECTED && request.correctedClass() == null) throw new ApiException("correctedClass is required", HttpStatus.BAD_REQUEST);
        if (request.decision() != AnalysisReviewDecision.CORRECTED && request.correctedClass() != null) throw new ApiException("correctedClass is only allowed for CORRECTED", HttpStatus.BAD_REQUEST);
        User reviewer = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        AnalysisReview review = reviewRepository.findByImageAnalysis(analysis).orElseGet(AnalysisReview::new);
        review.setImageAnalysis(analysis);
        review.setOriginalClass(analysis.getDiagnosisClass());
        review.setDecision(request.decision());
        review.setCorrectedClass(request.correctedClass());
        review.setComment(request.comment());
        review.setReviewedBy(reviewer);
        review.setReviewedAt(LocalDateTime.now());
        return map(reviewRepository.save(review));
    }

    @Transactional(readOnly = true)
    public AnalysisReviewResponse get(Long hospitalId, Long treatmentId, Long analysisId, UserDetails principal) {
        ImageAnalysis analysis = requireAnalysis(hospitalId, treatmentId, analysisId, principal);
        return reviewRepository.findByImageAnalysis(analysis)
                .map(this::map)
                .orElseGet(() -> new AnalysisReviewResponse(null, analysis.getImageAnalysisId(), null,
                        analysis.getDiagnosisClass(), null, null, null, null));
    }

    @Transactional(readOnly = true)
    public AnalysisExplanationResponse explanation(Long hospitalId, Long treatmentId, Long analysisId, UserDetails principal) {
        ImageAnalysis analysis = requireAnalysis(hospitalId, treatmentId, analysisId, principal);
        Map<Integer, Double> scores = scoreRepository.findAllByImageAnalysisOrderByClassLabel(analysis).stream()
                .collect(Collectors.toMap(AnalysisClassScore::getClassLabel, AnalysisClassScore::getScore, (a, b) -> a, LinkedHashMap::new));
        ImageFile heatmap = analysis.getHeatmapFile();
        ImageFileResponse heatmapResponse = heatmap == null ? null : ImageFileResponse.builder().id(heatmap.getImageFileId())
                .fileName(heatmap.getOriginalFileName()).contentType(heatmap.getImageFileType())
                .url("/api/files/" + heatmap.getImageFileId()).uploadedAt(heatmap.getUploadedAt()).build();
        SvmModelVersion model = analysis.getModelVersion();
        return new AnalysisExplanationResponse(analysisId, model == null ? null : model.getModelVersionId(),
                model == null ? null : model.getVersion(), heatmapResponse, scores, model == null ? null : model.getFeatureSet());
    }

    @Transactional(readOnly = true)
    public Page<AnalysisReviewResponse> reviewed(Long modelVersionId, AnalysisReviewDecision decision, Pageable pageable) {
        List<AnalysisReviewResponse> filtered = reviewRepository.findAll().stream()
                .filter(review -> decision == null || review.getDecision() == decision)
                .filter(review -> modelVersionId == null || review.getImageAnalysis().getModelVersion() != null && modelVersionId.equals(review.getImageAnalysis().getModelVersion().getModelVersionId()))
                .sorted(Comparator.comparing(AnalysisReview::getReviewedAt).reversed()).map(this::map).toList();
        int start = Math.min((int) pageable.getOffset(), filtered.size());
        int end = Math.min(start + pageable.getPageSize(), filtered.size());
        return new PageImpl<>(filtered.subList(start, end), pageable, filtered.size());
    }

    @Transactional
    public List<DatasetItemResponse> export(Long datasetId, ReviewedCasesExportRequest request, UserDetails principal) {
        ResearchDataset dataset = datasetService.requireDraft(datasetId);
        User reviewer = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        List<DatasetItemResponse> result = new ArrayList<>();
        for (Long analysisId : new LinkedHashSet<>(request.analysisIds())) {
            ImageAnalysis analysis = analysisRepository.findById(analysisId).orElseThrow(() -> new ApiException("Analysis not found", HttpStatus.NOT_FOUND));
            AnalysisReview review = reviewRepository.findByImageAnalysis(analysis).orElseThrow(() -> new ApiException("Analysis is not reviewed", HttpStatus.CONFLICT));
            if (review.getDecision() == AnalysisReviewDecision.REJECTED) throw new ApiException("Rejected analyses cannot be exported", HttpStatus.CONFLICT);
            if (datasetItemRepository.existsByDatasetAndSourceAnalysis(dataset, analysis)) continue;
            int label = review.getDecision() == AnalysisReviewDecision.CORRECTED ? review.getCorrectedClass() : review.getOriginalClass();
            DatasetItem item = datasetItemRepository.save(DatasetItem.builder().dataset(dataset).imageFile(analysis.getImageFile())
                    .sourceAnalysis(analysis).classLabel(label).labelSource(DatasetLabelSource.DOCTOR_REVIEW)
                    .reviewedBy(reviewer).reviewedAt(review.getReviewedAt()).build());
            result.add(datasetService.mapItem(item, null));
        }
        return result;
    }

    private ImageAnalysis requireAnalysis(Long hospitalId, Long treatmentId, Long analysisId, UserDetails principal) {
        User currentUser = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        ImageAnalysis analysis = analysisRepository.findById(analysisId).orElseThrow(() -> new ApiException("Analysis not found", HttpStatus.NOT_FOUND));
        Treatment treatment = analysis.getTreatment();
        if (treatment == null || !treatmentId.equals(treatment.getTreatmentId())
                || treatment.getHospital() == null || !hospitalId.equals(treatment.getHospital().getHospitalId())
                || analysis.getHospital() == null || !hospitalId.equals(analysis.getHospital().getHospitalId())) {
            throw new ApiException("Analysis not found", HttpStatus.NOT_FOUND);
        }
        if (!canAccessAnalysis(currentUser, treatment, analysis)) {
            throw new ApiException("Немає доступу до лікування", HttpStatus.FORBIDDEN);
        }
        return analysis;
    }

    private boolean canAccessAnalysis(User user, Treatment treatment, ImageAnalysis analysis) {
        return accessPolicy.canManageHospital(user, treatment.getHospital())
                || treatment.getPrimaryDoctor().getUserId().equals(user.getUserId())
                || analysis.getDoctor().getUserId().equals(user.getUserId());
    }

    private AnalysisReviewResponse map(AnalysisReview review) {
        return new AnalysisReviewResponse(review.getAnalysisReviewId(), review.getImageAnalysis().getImageAnalysisId(), review.getDecision(),
                review.getOriginalClass(), review.getCorrectedClass(), review.getComment(), review.getReviewedBy().getUserId(), review.getReviewedAt());
    }
}
