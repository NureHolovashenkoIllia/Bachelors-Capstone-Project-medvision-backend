package ua.nure.holovashenko.medvisionspring.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ua.nure.holovashenko.medvisionspring.dto.AnalysisJobResponse;
import org.springframework.http.HttpStatus;
import ua.nure.holovashenko.medvisionspring.service.DoctorAnalysisService;

import java.io.IOException;

@RestController
@RequestMapping("/api/hospitals/{hospitalId}/treatments/{treatmentId}/analyses")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
public class TreatmentAnalysisController {

    private final DoctorAnalysisService doctorAnalysisService;

    @PostMapping
    public ResponseEntity<AnalysisJobResponse> uploadAndAnalyzeImage(
            @PathVariable Long hospitalId,
            @PathVariable Long treatmentId,
            @RequestParam("file") MultipartFile file,
            @RequestParam(required = false) Long modelId,
            @AuthenticationPrincipal UserDetails userDetails
    ) throws IOException {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(doctorAnalysisService.submit(file, hospitalId, treatmentId, modelId, userDetails));
    }
}
