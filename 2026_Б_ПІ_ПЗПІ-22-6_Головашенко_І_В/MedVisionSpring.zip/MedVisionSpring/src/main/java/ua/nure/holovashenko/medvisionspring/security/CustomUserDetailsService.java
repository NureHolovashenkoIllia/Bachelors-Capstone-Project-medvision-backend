package ua.nure.holovashenko.medvisionspring.security;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;

import java.util.Collections;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Користувача не знайдено: " + email));

        UserAccountStatus status = user.getAccountStatus();
        return org.springframework.security.core.userdetails.User.withUsername(user.getEmail())
                .password(user.getPw())
                .authorities(Collections.singleton(new SimpleGrantedAuthority("ROLE_" + user.getUserRole().name())))
                .disabled(status == UserAccountStatus.DISABLED || status == UserAccountStatus.PENDING_VERIFICATION)
                .accountLocked(status == UserAccountStatus.LOCKED)
                .build();
    }
}
