package ua.nure.holovashenko.medvisionspring.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.AnalysisJobResponse;
import ua.nure.holovashenko.medvisionspring.service.AnalysisJobService;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisJobStatus;
import java.util.List;

@RestController
@RequestMapping("/api/hospitals/{hospitalId}/analysis-jobs")
@RequiredArgsConstructor
@PreAuthorize("isAuthenticated()")
public class AnalysisJobController {

    private final AnalysisJobService analysisJobService;

    @GetMapping("/{jobId}")
    public ResponseEntity<AnalysisJobResponse> getJob(
            @PathVariable Long hospitalId,
            @PathVariable Long jobId,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        return ResponseEntity.ok(analysisJobService.getJob(hospitalId, jobId, userDetails));
    }
    @GetMapping
    public ResponseEntity<List<AnalysisJobResponse>> list(@PathVariable Long hospitalId,
            @RequestParam(required = false) Long treatmentId, @RequestParam(required = false) AnalysisJobStatus status,
            @AuthenticationPrincipal UserDetails principal) {
        return ResponseEntity.ok(analysisJobService.list(hospitalId, treatmentId, status, principal));
    }

    @PostMapping("/{jobId}/retry")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public ResponseEntity<AnalysisJobResponse> retry(@PathVariable Long hospitalId, @PathVariable Long jobId,
            @AuthenticationPrincipal UserDetails principal) {
        return ResponseEntity.accepted().body(analysisJobService.retry(hospitalId, jobId, principal));
    }
}
