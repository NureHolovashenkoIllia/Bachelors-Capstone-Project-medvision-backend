package ua.nure.holovashenko.medvisionspring.svm;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bytedeco.opencv.opencv_core.*;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ua.nure.holovashenko.medvisionspring.config.SvmRuntimeProperties;
import ua.nure.holovashenko.medvisionspring.enums.SvmRuntimeStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.exception.SvmModelLoadException;

import java.io.File;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SvmService {

    private final SvmModelManager modelManager;
    private final DatasetLoader datasetLoader;
    private final ImagePatchExtractor patchExtractor;
    private final MetricsCalculator metricsCalculator;
    private final HeatmapGenerator heatmapGenerator;
    private final ImageUtils imageUtils;
    private final SvmRuntimeProperties runtimeProperties;

    private final Object modelLoadLock = new Object();

    public static final Map<Integer, DiagnosisInfo> CLASS_LABELS = Map.of(
            0, new DiagnosisInfo(
                    "The lung structure appears within normal limits, with no detected pathological changes.",
                    "Healthy — no signs of pathology were detected; the lungs show a normal structural pattern.",
                    "No immediate additional diagnostic procedure is required. Annual preventive screening is recommended."
            ),
            1, new DiagnosisInfo(
                    "Non-specific visual findings were detected and cannot be assigned to a defined disease class.",
                    "Other — the detected findings do not correspond to one of the main pathology classes.",
                    "Repeat imaging or consultation with a relevant specialist is recommended."
            ),
            2, new DiagnosisInfo(
                    "Infiltrative changes typical for pneumonia were detected, especially in the lower lung regions.",
                    "Pneumonia — inflammatory lung disease, often infection-related, commonly associated with infiltrates.",
                    "Clinical assessment is recommended; antibiotic therapy and follow-up imaging in 7-10 days may be considered."
            ),
            3, new DiagnosisInfo(
                    "Alveolar enlargement and disruption of lung tissue structure were observed.",
                    "Emphysema — chronic lung disease associated with alveolar damage and reduced respiratory efficiency.",
                    "Pulmonologist consultation, supportive therapy, and smoking cessation should be considered."
            ),
            4, new DiagnosisInfo(
                    "Areas of scarring and increased density in lung tissue were detected.",
                    "Fibrosis — scarring of lung tissue that may restrict breathing and reduce lung capacity.",
                    "Pulmonologist consultation is recommended; antifibrotic therapy may be considered depending on clinical context."
            )
    );


    @Async
    @EventListener(ApplicationReadyEvent.class)
    public void preloadModelsInBackground() {
        if (!runtimeProperties.preloadEnabled()) {
            log.info("SVM model preload is disabled by configuration.");
            return;
        }
        log.info("Starting async preload of SVM models...");
        try {
            modelManager.loadModels();
            log.info("SVM models preloaded successfully.");
        } catch (SvmModelLoadException e) {
            log.error("SVM model preload failed");
        }
    }

    public void trainFromDirectory(String datasetPath, boolean isPatchModel) {
        Dataset dataset = datasetLoader.loadDataset(datasetPath);
        if (isPatchModel) {
            modelManager.trainPatchModel(dataset);
        } else {
            modelManager.trainFullImageModel(dataset);
        }
    }

    public int classify(File imageFile, boolean isPatchModel) {
        ensureModelsReady();
        return modelManager.classify(imageFile, isPatchModel);
    }

    public int classify(File imageFile, File modelFile) {
        ensureModelsReady();
        return modelManager.classify(imageFile, modelFile);
    }

    public float evaluate(List<File> images, List<Integer> labels, boolean isPatchModel) {
        ensureModelsReady();
        return modelManager.evaluate(images, labels, isPatchModel);
    }

    public Map<Integer, Integer> detectPathologyCounts(File imageFile) {
        ensureModelsReady();
        return modelManager.detectPatchPathologies(imageFile);
    }

    public Mat generateHeatmap(File imageFile, boolean isPatchModel) {
        ensureModelsReady();
        Mat inputImage = ImageUtils.loadAndResizeImage(imageFile.getAbsolutePath());
        double[][] heatmapData = modelManager.getHeatmapData(imageFile, isPatchModel);
        return heatmapGenerator.generateHeatmap(inputImage, heatmapData);
    }

    public void saveModel(String path, boolean isPatchModel) {
        ensureModelsReady();
        modelManager.saveModel(path, isPatchModel);
    }

    public byte[] matToBytes(Mat mat, String format) {
        return imageUtils.matToBytes(mat, format);
    }

    public void saveMatToFile(Mat mat, File file) {
        imageUtils.saveMatToFile(mat, file);
    }

    public ModelMetrics loadMetrics(String path) {
        return metricsCalculator.loadMetricsFromAzure(path);
    }

    private void ensureModelsReady() {
        if (modelManager.getStatus() == SvmRuntimeStatus.FAILED) {
            throw new ApiException("MODEL_LOAD_FAILED", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (!modelManager.areModelsReady()) {
            synchronized (modelLoadLock) {
                if (!modelManager.areModelsReady()) {
                    log.info("SVM models are not ready. Loading models synchronously before request processing...");
                    try {
                        modelManager.loadModels();
                    } catch (SvmModelLoadException e) {
                        throw new ApiException("MODEL_LOAD_FAILED", HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                }
            }
        }

        if (!modelManager.areModelsReady()) {
            throw new ApiException("MODEL_NOT_READY", HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
}
