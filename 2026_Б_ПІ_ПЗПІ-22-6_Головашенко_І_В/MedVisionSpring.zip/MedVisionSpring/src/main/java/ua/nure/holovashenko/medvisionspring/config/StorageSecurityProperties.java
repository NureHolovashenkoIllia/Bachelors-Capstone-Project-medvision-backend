package ua.nure.holovashenko.medvisionspring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "medvision.storage")
public record StorageSecurityProperties(long maximumUploadBytes) {
}
