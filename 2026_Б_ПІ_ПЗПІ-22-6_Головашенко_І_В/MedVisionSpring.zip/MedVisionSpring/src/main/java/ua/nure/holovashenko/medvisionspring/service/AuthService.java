package ua.nure.holovashenko.medvisionspring.service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.entity.Doctor;
import ua.nure.holovashenko.medvisionspring.entity.Patient;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.entity.UserHospitalMembership;
import ua.nure.holovashenko.medvisionspring.enums.Gender;
import ua.nure.holovashenko.medvisionspring.enums.MembershipStatus;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;
import ua.nure.holovashenko.medvisionspring.enums.AuditOutcome;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.DoctorRepository;
import ua.nure.holovashenko.medvisionspring.repository.PatientRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserHospitalMembershipRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.security.JwtService;

import java.util.List;
import java.time.LocalDateTime;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final UserHospitalMembershipRepository membershipRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final AuthSessionService authSessionService;
    private final AccountSecurityProperties accountProperties;
    private final AuditService auditService;

    public AuthResponse registerPatient(PatientRegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ApiException("Користувач з таким email вже існує", HttpStatus.CONFLICT);
        }

        User user = new User();
        user.setUserName(request.getName());
        user.setEmail(request.getEmail());
        user.setPw(passwordEncoder.encode(request.getPassword()));
        user.setUserRole(UserRole.PATIENT);

        User savedUser = userRepository.save(user);

        Patient patient = new Patient();
        patient.setUser(savedUser);
        patient.setBirthDate(request.getBirthDate());
        if (request.getGender() != null && !request.getGender().isBlank()) {
            patient.setGender(Gender.valueOf(request.getGender().toUpperCase(Locale.ROOT)));
        }
        patientRepository.save(patient);

        return authSessionService.create(savedUser, null, null);
    }

    public AuthResponse login(LoginRequest request, String userAgent, String ipAddress) {
        User existingUser = userRepository.findByEmail(request.getEmail()).orElse(null);
        if (existingUser != null && existingUser.getAccountStatus() == UserAccountStatus.LOCKED
                && existingUser.getLockedUntil() != null && existingUser.getLockedUntil().isBefore(LocalDateTime.now())) {
            existingUser.setAccountStatus(UserAccountStatus.ACTIVE);
            existingUser.setFailedLoginAttempts(0);
            existingUser.setLockedUntil(null);
            userRepository.save(existingUser);
        }
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );
        } catch (AuthenticationException e) {
            registerFailedLogin(existingUser);
            auditService.recordIndependent(existingUser, null, "LOGIN", "User",
                    existingUser != null ? existingUser.getUserId().toString() : null,
                    AuditOutcome.FAILURE, null);
            throw new ApiException("Невірна електронна пошта або пароль", HttpStatus.UNAUTHORIZED);
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ApiException("Користувач не знайдений", HttpStatus.NOT_FOUND));

        user.setFailedLoginAttempts(0);
        user.setLockedUntil(null);
        userRepository.save(user);
        AuthResponse response = authSessionService.create(user, userAgent, ipAddress);
        auditService.record(user, null, "LOGIN", "User", user.getUserId().toString(), AuditOutcome.SUCCESS, null);
        return response;
    }

    private void registerFailedLogin(User user) {
        if (user == null || user.getAccountStatus() == UserAccountStatus.DISABLED) {
            return;
        }
        int attempts = user.getFailedLoginAttempts() == null ? 1 : user.getFailedLoginAttempts() + 1;
        user.setFailedLoginAttempts(attempts);
        if (attempts >= accountProperties.maximumFailedLogins()) {
            user.setAccountStatus(UserAccountStatus.LOCKED);
            user.setLockedUntil(LocalDateTime.now().plusMinutes(accountProperties.lockDurationMinutes()));
        }
        userRepository.save(user);
    }

    public UserProfileResponse getProfile(UserDetails userDetails) {
        User user = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));

        return switch (user.getUserRole()) {
            case DOCTOR -> {
                Doctor doctor = doctorRepository.findByUser(user)
                        .orElseThrow(() -> new ApiException("Дані лікаря не знайдені", HttpStatus.NOT_FOUND));
                yield DoctorProfileResponse.builder()
                        .id(user.getUserId())
                        .name(user.getUserName())
                        .email(user.getEmail())
                        .role(user.getUserRole())
                        .position(doctor.getPosition())
                        .department(doctor.getDepartment())
                        .licenseNumber(doctor.getLicenseNumber())
                        .achievements(doctor.getAchievements())
                        .medicalInstitution(doctor.getMedicalInstitution())
                        .education(doctor.getEducation())
                        .hospitals(getHospitalResponses(user))
                        .build();
            }
            case PATIENT -> {
                Patient patient = patientRepository.findByUser(user)
                        .orElseThrow(() -> new ApiException("Дані пацієнта не знайдені", HttpStatus.NOT_FOUND));
                yield PatientProfileResponse.builder()
                        .id(user.getUserId())
                        .name(user.getUserName())
                        .email(user.getEmail())
                        .role(user.getUserRole())
                        .birthDate(patient.getBirthDate())
                        .gender(patient.getGender() != null ? patient.getGender().name() : null)
                        .heightCm(patient.getHeightCm())
                        .weightKg(patient.getWeightKg())
                        .chronicDiseases(patient.getChronicDiseases())
                        .allergies(patient.getAllergies())
                        .address(patient.getAddress())
                        .lastExamDate(patient.getLastExamDate())
                        .hospitals(getHospitalResponses(user))
                        .build();
            }
            case ADMIN -> {
                yield AdminProfileResponse.builder()
                        .id(user.getUserId())
                        .name(user.getUserName())
                        .email(user.getEmail())
                        .role(user.getUserRole())
                        .hospitals(getHospitalResponses(user))
                        .build();
            }
            default -> throw new ApiException("Невідома роль", HttpStatus.BAD_REQUEST);
        };
    }

    @Transactional
    public UserProfileResponse editDoctorProfile(UserDetails userDetails, DoctorEditRequest request) {
        User user = getUser(userDetails);
        Doctor doctor = doctorRepository.findByUser(user)
                .orElseThrow(() -> new ApiException("Дані лікаря не знайдені", HttpStatus.NOT_FOUND));

        updateUser(user, request.getName());
        doctor.setPosition(request.getPosition());
        doctor.setDepartment(request.getDepartment());
        doctor.setLicenseNumber(request.getLicenseNumber());
        doctor.setAchievements(request.getAchievements());
        doctor.setEducation(request.getEducation());
        doctor.setMedicalInstitution(request.getMedicalInstitution());

        return getProfile(userDetails);
    }

    @Transactional
    public UserProfileResponse editPatientProfile(UserDetails userDetails, PatientEditRequest request) {
        User user = getUser(userDetails);
        Patient patient = patientRepository.findByUser(user)
                .orElseThrow(() -> new ApiException("Дані пацієнта не знайдені", HttpStatus.NOT_FOUND));

        updateUser(user, request.getName());
        patient.setGender(Gender.valueOf(request.getGender().toUpperCase(Locale.ROOT)));
        patient.setBirthDate(request.getBirthDate());
        patient.setHeightCm(request.getHeightCm());
        patient.setWeightKg(request.getWeightKg());
        patient.setChronicDiseases(request.getChronicDiseases());
        patient.setAllergies(request.getAllergies());
        patient.setAddress(request.getAddress());

        return getProfile(userDetails);
    }

    private User getUser(UserDetails userDetails) {
        return userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));
    }

    private void updateUser(User user, String name) {
        user.setUserName(name);
    }

    private List<MyHospitalResponse> getHospitalResponses(User user) {
        return membershipRepository.findAllByUserAndStatus(user, MembershipStatus.ACTIVE).stream()
                .map(this::mapMembershipToHospitalResponse)
                .toList();
    }

    private MyHospitalResponse mapMembershipToHospitalResponse(UserHospitalMembership membership) {
        return MyHospitalResponse.builder()
                .hospitalId(membership.getHospital().getHospitalId())
                .name(membership.getHospital().getName())
                .code(membership.getHospital().getCode())
                .hospitalRole(membership.getHospitalRole())
                .membershipStatus(membership.getStatus())
                .build();
    }
}
