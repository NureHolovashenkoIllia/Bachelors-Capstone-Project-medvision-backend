package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.DatasetItem;
import ua.nure.holovashenko.medvisionspring.entity.ImageAnalysis;
import ua.nure.holovashenko.medvisionspring.entity.ResearchDataset;

import java.util.List;

public interface DatasetItemRepository extends JpaRepository<DatasetItem, Long> {
    List<DatasetItem> findAllByDatasetOrderByDatasetItemId(ResearchDataset dataset);
    long countByDatasetAndClassLabel(ResearchDataset dataset, Integer classLabel);
    boolean existsByDatasetAndSourceAnalysis(ResearchDataset dataset, ImageAnalysis analysis);
}
