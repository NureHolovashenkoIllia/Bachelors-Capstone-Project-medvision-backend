package ua.nure.holovashenko.medvisionspring.enums;

public enum DatasetLabelSource {
    MANUAL,
    DOCTOR_REVIEW
}
