package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public record DatasetSplitCreateRequest(
        @NotNull @DecimalMin("0.0") @DecimalMax("1.0") Double trainRatio,
        @NotNull @DecimalMin("0.0") @DecimalMax("1.0") Double validationRatio,
        @NotNull @DecimalMin("0.0") @DecimalMax("1.0") Double testRatio,
        @NotNull Long seed
) {}
