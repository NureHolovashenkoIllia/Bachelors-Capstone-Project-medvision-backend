package ua.nure.holovashenko.medvisionspring.exception;

public class SvmModelLoadException extends RuntimeException {

    public SvmModelLoadException(String message) {
        super(message);
    }

    public SvmModelLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}
