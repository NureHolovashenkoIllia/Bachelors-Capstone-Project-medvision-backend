package ua.nure.holovashenko.medvisionspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import ua.nure.holovashenko.medvisionspring.config.AdminBootstrapProperties;
import ua.nure.holovashenko.medvisionspring.config.CorsProperties;
import ua.nure.holovashenko.medvisionspring.config.FrontendProperties;
import ua.nure.holovashenko.medvisionspring.config.SvmRuntimeProperties;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.config.StorageSecurityProperties;

@SpringBootApplication
@ComponentScan(basePackages = {
        "ua.nure.holovashenko.medvisionspring.config",
        "ua.nure.holovashenko.medvisionspring.controller",
        "ua.nure.holovashenko.medvisionspring.dto",
        "ua.nure.holovashenko.medvisionspring.entity",
        "ua.nure.holovashenko.medvisionspring.enums",
        "ua.nure.holovashenko.medvisionspring.exception",
        "ua.nure.holovashenko.medvisionspring.repository",
        "ua.nure.holovashenko.medvisionspring.security",
        "ua.nure.holovashenko.medvisionspring.service",
        "ua.nure.holovashenko.medvisionspring.storage",
        "ua.nure.holovashenko.medvisionspring.util",
        "ua.nure.holovashenko.medvisionspring.svm"
})
@EntityScan(basePackages = {
        "ua.nure.holovashenko.medvisionspring.entity"
})
@EnableJpaRepositories(basePackages = {
        "ua.nure.holovashenko.medvisionspring.repository"
})
@EnableAsync
@EnableScheduling
@EnableConfigurationProperties({
        AdminBootstrapProperties.class,
        CorsProperties.class,
        FrontendProperties.class,
        SvmRuntimeProperties.class,
        AccountSecurityProperties.class,
        StorageSecurityProperties.class
})
public class MedVisionSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedVisionSpringApplication.class, args);
    }

}
