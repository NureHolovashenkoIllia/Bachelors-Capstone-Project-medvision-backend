package ua.nure.holovashenko.medvisionspring.enums;

public enum SvmModelStatus {
    CANDIDATE,
    TRAINING,
    VALIDATED,
    ACTIVE,
    ARCHIVED,
    FAILED
}
