package ua.nure.holovashenko.medvisionspring.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ImageFileResponse {
    private Long id;
    private String fileName;
    private String contentType;
    private String url;
    private LocalDateTime uploadedAt;
}
