package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Pageable;
import jakarta.persistence.LockModeType;
import ua.nure.holovashenko.medvisionspring.entity.Treatment;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisJobStatus;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Repository;
import ua.nure.holovashenko.medvisionspring.entity.AnalysisJob;
import ua.nure.holovashenko.medvisionspring.entity.Hospital;

import java.util.Optional;

@Repository
public interface AnalysisJobRepository extends JpaRepository<AnalysisJob, Long> {
    Optional<AnalysisJob> findByAnalysisJobIdAndHospital(Long analysisJobId, Hospital hospital);

    List<AnalysisJob> findAllByHospitalOrderByCreatedAtDesc(Hospital hospital);
    List<AnalysisJob> findAllByHospitalAndTreatmentOrderByCreatedAtDesc(Hospital hospital, Treatment treatment);
    List<AnalysisJob> findAllByHospitalAndStatusOrderByCreatedAtDesc(Hospital hospital, AnalysisJobStatus status);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select job from AnalysisJob job where job.status = 'PENDING' and (job.nextAttemptAt is null or job.nextAttemptAt <= :now) order by job.createdAt")
    List<AnalysisJob> findClaimable(@Param("now") LocalDateTime now, Pageable pageable);
}
