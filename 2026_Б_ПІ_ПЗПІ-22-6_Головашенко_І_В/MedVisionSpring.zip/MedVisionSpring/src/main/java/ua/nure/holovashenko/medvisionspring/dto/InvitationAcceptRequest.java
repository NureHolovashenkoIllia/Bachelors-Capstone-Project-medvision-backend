package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record InvitationAcceptRequest(@NotBlank String token, @NotBlank @Size(min = 12) String password) {
}
