package ua.nure.holovashenko.medvisionspring.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.service.AuthService;
import ua.nure.holovashenko.medvisionspring.service.AuthSessionService;
import ua.nure.holovashenko.medvisionspring.service.AccountLifecycleService;
import ua.nure.holovashenko.medvisionspring.service.InvitationService;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final AuthSessionService authSessionService;
    private final AccountLifecycleService accountLifecycleService;
    private final InvitationService invitationService;
    private final UserRepository userRepository;

    @Operation(summary = "Реєстрація пацієнта")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Успішна реєстрація"),
            @ApiResponse(responseCode = "409", description = "Користувач з таким email вже існує")
    })
    @PostMapping("/register/patient")
    public ResponseEntity<AuthResponse> registerPatient(@Valid @RequestBody PatientRegisterRequest request) {
        return ResponseEntity.ok(authService.registerPatient(request));
    }

    @Operation(summary = "Авторизація користувача")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Успішна авторизація"),
            @ApiResponse(responseCode = "401", description = "Невірний email або пароль"),
            @ApiResponse(responseCode = "404", description = "Користувача не знайдено")
    })
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        return ResponseEntity.ok(authService.login(request, httpRequest.getHeader("User-Agent"), httpRequest.getRemoteAddr()));
    }

    @PostMapping("/token/refresh")
    public ResponseEntity<AuthResponse> refresh(@Valid @RequestBody TokenRefreshRequest request, HttpServletRequest httpRequest) {
        return ResponseEntity.ok(authSessionService.rotate(request.refreshToken(), httpRequest.getHeader("User-Agent"), httpRequest.getRemoteAddr()));
    }

    @PostMapping("/password/forgot")
    public ResponseEntity<Void> forgotPassword(@Valid @RequestBody PasswordForgotRequest request) {
        accountLifecycleService.requestPasswordReset(request.email());
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/password/reset")
    public ResponseEntity<Void> resetPassword(@Valid @RequestBody PasswordResetRequest request) {
        accountLifecycleService.resetPassword(request.token(), request.newPassword());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/invitations/accept")
    public ResponseEntity<Void> acceptInvitation(@Valid @RequestBody InvitationAcceptRequest request) {
        invitationService.accept(request);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@Valid @RequestBody TokenRefreshRequest request) {
        authSessionService.revoke(request.refreshToken());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/logout-all")
    public ResponseEntity<Void> logoutAll(@AuthenticationPrincipal UserDetails principal) {
        var user = userRepository.findByEmail(principal.getUsername()).orElseThrow();
        authSessionService.revokeAll(user);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Отримання профілю авторизованого користувача")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Профіль знайдено"),
            @ApiResponse(responseCode = "404", description = "Користувача не знайдено або відсутні розширені дані"),
            @ApiResponse(responseCode = "400", description = "Невідома роль користувача"),
            @ApiResponse(responseCode = "401", description = "Неавторизований запит")
    })
    @GetMapping("/profile")
    public ResponseEntity<?> profile(@AuthenticationPrincipal UserDetails userDetails) {
        try {
            return ResponseEntity.ok(authService.getProfile(userDetails));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).
                    body("{\"Помилка при отриманні профілю\":\"" + e.getMessage() + "\"}");
        }
    }

    @PutMapping("/edit/doctor")
    public ResponseEntity<?> editDoctorProfile(@AuthenticationPrincipal UserDetails userDetails,
                                               @Valid @RequestBody DoctorEditRequest request) {
        return ResponseEntity.ok(authService.editDoctorProfile(userDetails, request));
    }

    @PutMapping("/edit/patient")
    public ResponseEntity<?> editPatientProfile(@AuthenticationPrincipal UserDetails userDetails,
                                                @Valid @RequestBody PatientEditRequest request) {
        return ResponseEntity.ok(authService.editPatientProfile(userDetails, request));
    }

}
