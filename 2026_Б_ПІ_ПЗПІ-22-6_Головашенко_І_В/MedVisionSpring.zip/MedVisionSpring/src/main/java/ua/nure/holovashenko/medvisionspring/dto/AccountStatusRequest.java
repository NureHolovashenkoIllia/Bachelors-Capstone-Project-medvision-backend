package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;

public record AccountStatusRequest(@NotNull UserAccountStatus status, @NotBlank String reason) {
}
