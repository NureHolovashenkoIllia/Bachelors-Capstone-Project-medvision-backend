package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.dto.AuthResponse;
import ua.nure.holovashenko.medvisionspring.entity.AuthSession;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.AuditOutcome;
import ua.nure.holovashenko.medvisionspring.enums.UserAccountStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.AuthSessionRepository;
import ua.nure.holovashenko.medvisionspring.security.JwtService;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthSessionService {
    private final AuthSessionRepository repository;
    private final SecureTokenService tokenService;
    private final JwtService jwtService;
    private final AccountSecurityProperties properties;
    private final AuditService auditService;

    @Transactional
    public AuthResponse create(User user, String userAgent, String ipAddress) {
        String refreshToken = tokenService.generate();
        repository.save(AuthSession.builder()
                .user(user)
                .tokenHash(tokenService.hash(refreshToken))
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusDays(properties.refreshTokenDays()))
                .userAgent(limit(userAgent, 255))
                .ipAddress(limit(ipAddress, 64))
                .build());
        return new AuthResponse(jwtService.generateToken(user), refreshToken, jwtService.getExpirationSeconds());
    }

    @Transactional
    public AuthResponse rotate(String rawToken, String userAgent, String ipAddress) {
        AuthSession session = repository.findByTokenHash(tokenService.hash(rawToken))
                .orElseThrow(() -> new ApiException("Invalid refresh token", HttpStatus.UNAUTHORIZED));
        User user = session.getUser();
        if (session.getRevokedAt() != null || session.getExpiresAt().isBefore(LocalDateTime.now())
                || user.getAccountStatus() != UserAccountStatus.ACTIVE) {
            throw new ApiException("Invalid refresh token", HttpStatus.UNAUTHORIZED);
        }
        session.setRevokedAt(LocalDateTime.now());
        session.setLastUsedAt(LocalDateTime.now());
        repository.save(session);
        return create(user, userAgent, ipAddress);
    }

    @Transactional
    public void revoke(String rawToken, User user) {
        repository.findByTokenHash(tokenService.hash(rawToken)).ifPresent(session -> {
            if (!session.getUser().getUserId().equals(user.getUserId())) {
                throw new ApiException("Invalid refresh token", HttpStatus.FORBIDDEN);
            }
            session.setRevokedAt(LocalDateTime.now());
            repository.save(session);
        });
        auditService.record(user, null, "SESSION_REVOKED", "User", user.getUserId().toString(), AuditOutcome.SUCCESS, null);
    }

    @Transactional
    public void revoke(String rawToken) {
        repository.findByTokenHash(tokenService.hash(rawToken)).ifPresent(session -> {
            session.setRevokedAt(LocalDateTime.now());
            repository.save(session);
            User user = session.getUser();
            auditService.record(user, null, "SESSION_REVOKED", "User", user.getUserId().toString(), AuditOutcome.SUCCESS, null);
        });
    }

    @Transactional
    public void revokeAll(User user) {
        LocalDateTime now = LocalDateTime.now();
        repository.findAllByUserAndRevokedAtIsNull(user).forEach(session -> session.setRevokedAt(now));
    }

    private String limit(String value, int length) {
        return value == null ? null : value.substring(0, Math.min(value.length(), length));
    }
}
