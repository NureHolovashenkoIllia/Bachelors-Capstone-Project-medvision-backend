package ua.nure.holovashenko.medvisionspring.dto;

import lombok.Builder;
import lombok.Data;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisJobStatus;

import java.time.LocalDateTime;

@Data
@Builder
public class AnalysisJobResponse {
    private Long jobId;
    private Long analysisId;
    private Long hospitalId;
    private Long treatmentId;
    private Long modelVersionId;
    private AnalysisJobStatus status;
    private String errorMessage;
    private Integer attemptCount;
    private String correlationId;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;
    private LocalDateTime createdAt;
}
