package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "svm_experiment")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SvmExperiment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "experiment_id")
    private Long experimentId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "dataset_id", nullable = false)
    private ResearchDataset dataset;

    @Enumerated(EnumType.STRING)
    @Column(name = "model_type", nullable = false, length = 32)
    private SvmModelType modelType;

    @Enumerated(EnumType.STRING)
    @Column(name = "kernel_type", nullable = false, length = 32)
    private SvmKernelType kernelType;

    @Column(name = "c_value", nullable = false, precision = 18, scale = 8)
    private BigDecimal cValue;

    @Column(name = "gamma_value", precision = 18, scale = 8)
    private BigDecimal gammaValue;

    @Enumerated(EnumType.STRING)
    @Column(name = "multiclass_strategy", nullable = false, length = 32)
    private SvmMulticlassStrategy multiclassStrategy;

    @Column(name = "feature_set", nullable = false)
    private String featureSet;

    @Column(nullable = false)
    private Long seed;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private SvmExperimentStatus status;

    @Lob
    @Column(name = "failure_reason", columnDefinition = "TEXT")
    private String failureReason;

    @ManyToOne(optional = false)
    @JoinColumn(name = "created_by_user_id", nullable = false)
    private User createdBy;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "started_at")
    private LocalDateTime startedAt;

    @Column(name = "finished_at")
    private LocalDateTime finishedAt;

    @PrePersist
    void prePersist() {
        if (status == null) status = SvmExperimentStatus.CREATED;
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
