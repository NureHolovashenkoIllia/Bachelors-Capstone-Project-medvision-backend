package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SvmModelRegisterRequest(
        @NotNull Long experimentId,
        @NotBlank @Size(max = 255) String name,
        @NotBlank @Size(max = 64) String version
) {}
