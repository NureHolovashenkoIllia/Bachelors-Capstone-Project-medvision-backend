package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ua.nure.holovashenko.medvisionspring.entity.SvmModelVersion;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelStatus;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelType;

import java.util.List;
import java.util.Optional;
import jakarta.persistence.LockModeType;

@Repository
public interface SvmModelVersionRepository extends JpaRepository<SvmModelVersion, Long> {
    Optional<SvmModelVersion> findByVersion(String version);

    Optional<SvmModelVersion> findFirstByModelTypeAndStatusOrderByActivatedAtDesc(SvmModelType modelType, SvmModelStatus status);

    List<SvmModelVersion> findAllByStatus(SvmModelStatus status);

    boolean existsByVersion(String version);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select model from SvmModelVersion model where model.modelType = :modelType order by model.modelVersionId")
    List<SvmModelVersion> findAllByModelTypeForUpdate(@Param("modelType") SvmModelType modelType);
}
