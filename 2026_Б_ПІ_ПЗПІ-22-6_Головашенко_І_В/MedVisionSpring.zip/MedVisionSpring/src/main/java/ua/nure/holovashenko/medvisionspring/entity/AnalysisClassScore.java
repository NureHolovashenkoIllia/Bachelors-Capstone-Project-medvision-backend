package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "analysis_class_score")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AnalysisClassScore {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "analysis_class_score_id")
    private Long analysisClassScoreId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "image_analysis_id", nullable = false)
    private ImageAnalysis imageAnalysis;

    @Column(name = "class_label", nullable = false)
    private Integer classLabel;

    @Column(nullable = false)
    private Double score;
}
