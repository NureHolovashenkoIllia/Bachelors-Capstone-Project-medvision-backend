package ua.nure.holovashenko.medvisionspring.dto;

public record FileDownloadResponse(
        String fileName,
        String contentType,
        byte[] content
) {
}
