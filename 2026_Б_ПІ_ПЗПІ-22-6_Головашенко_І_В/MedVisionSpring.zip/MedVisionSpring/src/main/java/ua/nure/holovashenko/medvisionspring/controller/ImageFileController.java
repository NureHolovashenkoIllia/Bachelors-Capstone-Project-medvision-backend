package ua.nure.holovashenko.medvisionspring.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ua.nure.holovashenko.medvisionspring.dto.FileDownloadResponse;
import ua.nure.holovashenko.medvisionspring.service.ImageFileService;

@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
public class ImageFileController {

    private final ImageFileService imageFileService;

    @GetMapping("/{fileId}")
    public ResponseEntity<byte[]> downloadFile(
            @PathVariable Long fileId,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        FileDownloadResponse file = imageFileService.downloadFile(fileId, userDetails);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(file.contentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.inline()
                        .filename(file.fileName())
                        .build()
                        .toString())
                .body(file.content());
    }
}
