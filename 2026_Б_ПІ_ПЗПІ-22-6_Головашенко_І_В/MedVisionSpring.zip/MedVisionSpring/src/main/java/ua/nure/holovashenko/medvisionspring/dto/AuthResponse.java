package ua.nure.holovashenko.medvisionspring.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class AuthResponse {
    private String token;
    private String refreshToken;
    private long expiresInSeconds;

    public AuthResponse(String token) {
        this(token, null, 0);
    }

    public AuthResponse(String token, String refreshToken, long expiresInSeconds) {
        this.token = token;
        this.refreshToken = refreshToken;
        this.expiresInSeconds = expiresInSeconds;
    }
}
