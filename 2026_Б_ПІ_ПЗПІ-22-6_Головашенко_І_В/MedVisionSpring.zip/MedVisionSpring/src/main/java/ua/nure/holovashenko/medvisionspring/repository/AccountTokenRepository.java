package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.AccountToken;
import ua.nure.holovashenko.medvisionspring.enums.AccountTokenPurpose;
import java.util.Optional;

public interface AccountTokenRepository extends JpaRepository<AccountToken, Long> {
    Optional<AccountToken> findByTokenHashAndPurpose(String tokenHash, AccountTokenPurpose purpose);
}
