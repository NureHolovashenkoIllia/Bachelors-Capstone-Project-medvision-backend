package ua.nure.holovashenko.medvisionspring.enums;

public enum ResearchDatasetStatus {
    DRAFT,
    FROZEN
}
