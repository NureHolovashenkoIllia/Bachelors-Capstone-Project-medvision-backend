package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.ResearchDataset;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperiment;
import ua.nure.holovashenko.medvisionspring.enums.SvmExperimentStatus;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelType;

import java.util.List;

public interface SvmExperimentRepository extends JpaRepository<SvmExperiment, Long> {
    List<SvmExperiment> findAllByOrderByCreatedAtDesc();
    List<SvmExperiment> findAllByDatasetOrderByCreatedAtDesc(ResearchDataset dataset);
    List<SvmExperiment> findAllByStatusOrderByCreatedAtDesc(SvmExperimentStatus status);
    List<SvmExperiment> findAllByModelTypeOrderByCreatedAtDesc(SvmModelType modelType);
}
