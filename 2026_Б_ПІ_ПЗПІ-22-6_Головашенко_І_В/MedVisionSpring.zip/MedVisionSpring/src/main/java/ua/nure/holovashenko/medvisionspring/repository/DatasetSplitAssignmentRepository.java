package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ua.nure.holovashenko.medvisionspring.entity.DatasetSplitAssignment;
import ua.nure.holovashenko.medvisionspring.entity.ResearchDataset;
import ua.nure.holovashenko.medvisionspring.enums.DatasetSplit;

import java.util.List;

public interface DatasetSplitAssignmentRepository extends JpaRepository<DatasetSplitAssignment, Long> {
    @Query("select a from DatasetSplitAssignment a where a.datasetItem.dataset = :dataset order by a.datasetItem.datasetItemId")
    List<DatasetSplitAssignment> findAllByDataset(ResearchDataset dataset);

    @Query("select a from DatasetSplitAssignment a where a.datasetItem.dataset = :dataset and a.datasetSplit = :split order by a.datasetItem.datasetItemId")
    List<DatasetSplitAssignment> findAllByDatasetAndSplit(ResearchDataset dataset, DatasetSplit split);

    @Query("delete from DatasetSplitAssignment a where a.datasetItem.dataset = :dataset")
    @org.springframework.data.jpa.repository.Modifying
    void deleteAllByDataset(ResearchDataset dataset);
}
