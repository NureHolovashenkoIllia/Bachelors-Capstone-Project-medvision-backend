package ua.nure.holovashenko.medvisionspring.dto;

import java.time.LocalDateTime;

public record DoctorInvitationResponse(Long invitationId, String token, LocalDateTime expiresAt) {
}
