package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import ua.nure.holovashenko.medvisionspring.enums.HospitalRole;

public record DoctorInvitationRequest(
        @NotNull Long hospitalId,
        @NotBlank @Email String email,
        @NotBlank String name,
        @NotNull HospitalRole hospitalRole,
        String position,
        String department,
        String licenseNumber
) {
}
