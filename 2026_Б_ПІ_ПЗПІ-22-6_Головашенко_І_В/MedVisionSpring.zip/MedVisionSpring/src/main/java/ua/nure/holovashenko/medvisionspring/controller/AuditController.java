package ua.nure.holovashenko.medvisionspring.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.AuditEventResponse;
import ua.nure.holovashenko.medvisionspring.service.AuditService;

@RestController
@RequestMapping("/api/admin/audit-events")
@RequiredArgsConstructor
public class AuditController {
    private final AuditService auditService;

    @GetMapping
    public Page<AuditEventResponse> list(@RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "20") int size) {
        return auditService.findAll(page, size).map(event -> new AuditEventResponse(
                event.getAuditEventId(), event.getActor() == null ? null : event.getActor().getUserId(),
                event.getHospital() == null ? null : event.getHospital().getHospitalId(), event.getAction(),
                event.getResourceType(), event.getResourceId(), event.getOutcome(), event.getCorrelationId(),
                event.getMetadata(), event.getOccurredAt()));
    }
}
