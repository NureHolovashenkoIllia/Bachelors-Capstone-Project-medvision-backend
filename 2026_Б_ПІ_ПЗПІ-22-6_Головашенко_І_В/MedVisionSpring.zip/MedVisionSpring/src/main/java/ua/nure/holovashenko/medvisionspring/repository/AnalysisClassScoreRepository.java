package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.AnalysisClassScore;
import ua.nure.holovashenko.medvisionspring.entity.ImageAnalysis;

import java.util.List;

public interface AnalysisClassScoreRepository extends JpaRepository<AnalysisClassScore, Long> {
    List<AnalysisClassScore> findAllByImageAnalysisOrderByClassLabel(ImageAnalysis imageAnalysis);
}
