package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record ReviewedCasesExportRequest(@NotEmpty List<Long> analysisIds) {}
