package ua.nure.holovashenko.medvisionspring.dto;

import java.util.List;

public record ConfusionMatrixResponse(Long experimentId, List<Integer> labels, int[][] matrix) {}
