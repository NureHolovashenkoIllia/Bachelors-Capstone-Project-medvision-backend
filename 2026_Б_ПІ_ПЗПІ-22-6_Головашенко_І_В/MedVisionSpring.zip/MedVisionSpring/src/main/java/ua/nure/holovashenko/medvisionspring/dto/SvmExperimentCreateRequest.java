package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import ua.nure.holovashenko.medvisionspring.enums.SvmKernelType;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelType;
import ua.nure.holovashenko.medvisionspring.enums.SvmMulticlassStrategy;

import java.math.BigDecimal;

public record SvmExperimentCreateRequest(
        @NotNull Long datasetId,
        @NotNull SvmModelType modelType,
        @NotNull SvmKernelType kernelType,
        @NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal c,
        @DecimalMin(value = "0.0", inclusive = false) BigDecimal gamma,
        @NotNull SvmMulticlassStrategy multiclassStrategy,
        @NotBlank String featureSet,
        @NotNull Long seed
) {}
