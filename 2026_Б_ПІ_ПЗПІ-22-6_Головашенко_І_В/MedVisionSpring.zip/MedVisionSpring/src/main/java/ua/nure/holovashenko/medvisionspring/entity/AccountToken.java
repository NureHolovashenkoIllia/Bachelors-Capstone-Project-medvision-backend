package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.AccountTokenPurpose;
import java.time.LocalDateTime;

@Entity
@Table(name = "account_token")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountToken {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "account_token_id")
    private Long accountTokenId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @ManyToOne
    @JoinColumn(name = "hospital_id")
    private Hospital hospital;
    @Column(name = "token_hash", nullable = false, unique = true, length = 64)
    private String tokenHash;
    @Enumerated(EnumType.STRING)
    @Column(name = "purpose", nullable = false, length = 32)
    private AccountTokenPurpose purpose;
    @Column(name = "target_email", length = 100)
    private String targetEmail;
    @Lob
    @Column(name = "payload", columnDefinition = "TEXT")
    private String payload;
    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    @Column(name = "consumed_at")
    private LocalDateTime consumedAt;
    @ManyToOne
    @JoinColumn(name = "created_by_user_id")
    private User createdBy;
}
