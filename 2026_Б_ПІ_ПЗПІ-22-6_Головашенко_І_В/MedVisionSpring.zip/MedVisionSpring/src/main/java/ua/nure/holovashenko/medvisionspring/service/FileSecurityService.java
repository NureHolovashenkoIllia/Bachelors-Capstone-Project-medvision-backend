package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ua.nure.holovashenko.medvisionspring.config.StorageSecurityProperties;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import java.io.File;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
public class FileSecurityService {
    private final StorageSecurityProperties properties;

    public ValidatedUpload validate(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ApiException("Image file is empty", HttpStatus.BAD_REQUEST);
        }
        if (file.getSize() > properties.maximumUploadBytes()) {
            throw new ApiException("Image file exceeds the configured size limit", HttpStatus.PAYLOAD_TOO_LARGE);
        }
        try {
            byte[] header = file.getInputStream().readNBytes(12);
            String contentType = detectContentType(header);
            return new ValidatedUpload(safeOriginalName(file.getOriginalFilename()), contentType, file.getSize());
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException("Unable to validate image file", HttpStatus.BAD_REQUEST);
        }
    }

    public StoredMetadata metadata(File file, String storageKey, String originalName, String contentType) {
        try {
            byte[] bytes = Files.readAllBytes(file.toPath());
            return new StoredMetadata(storageKey, originalName, contentType, (long) bytes.length,
                    HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
        } catch (Exception e) {
            throw new IllegalStateException("Unable to calculate stored file metadata", e);
        }
    }

    private String detectContentType(byte[] header) {
        if (header.length >= 8 && (header[0] & 0xff) == 0x89 && header[1] == 0x50 && header[2] == 0x4e
                && header[3] == 0x47 && header[4] == 0x0d && header[5] == 0x0a && header[6] == 0x1a && header[7] == 0x0a) {
            return "image/png";
        }
        if (header.length >= 3 && (header[0] & 0xff) == 0xff && (header[1] & 0xff) == 0xd8 && (header[2] & 0xff) == 0xff) {
            return "image/jpeg";
        }
        throw new ApiException("Only valid PNG and JPEG images are supported", HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    private String safeOriginalName(String value) {
        String name = value == null ? "scan" : value.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).replaceAll("[^A-Za-z0-9._-]", "_");
        if (name.isBlank()) {
            name = "scan";
        }
        return name.substring(0, Math.min(name.length(), 120));
    }

    public record ValidatedUpload(String originalName, String contentType, long sizeBytes) {}
    public record StoredMetadata(String storageKey, String originalName, String contentType,
                                 long sizeBytes, String checksumSha256) {}
}
