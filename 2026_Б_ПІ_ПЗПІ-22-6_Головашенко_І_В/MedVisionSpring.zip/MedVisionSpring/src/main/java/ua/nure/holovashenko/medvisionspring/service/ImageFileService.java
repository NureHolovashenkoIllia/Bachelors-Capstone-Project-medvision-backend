package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import ua.nure.holovashenko.medvisionspring.dto.FileDownloadResponse;
import ua.nure.holovashenko.medvisionspring.entity.ImageFile;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.ImageFileRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.storage.ResilientBlobStorageService;

import java.io.IOException;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class ImageFileService {

    private final ImageFileRepository imageFileRepository;
    private final UserRepository userRepository;
    private final HospitalAccessPolicy hospitalAccessPolicy;
    private final ResilientBlobStorageService storageService;

    public FileDownloadResponse downloadFile(Long fileId, UserDetails userDetails) {
        ImageFile imageFile = imageFileRepository.findById(fileId)
                .orElseThrow(() -> new ApiException("Файл не знайдено", HttpStatus.NOT_FOUND));
        User currentUser = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));

        validateAccess(imageFile, currentUser);
        if (imageFile.getDeletedAt() != null) {
            throw new ApiException("Файл не знайдено", HttpStatus.NOT_FOUND);
        }

        try {
            byte[] content = imageFile.getStorageKey() != null
                    ? storageService.downloadFileByName(imageFile.getStorageKey())
                    : storageService.downloadFileFromBlobUrl(imageFile.getImageFileUrl());
            return new FileDownloadResponse(
                    imageFile.getOriginalFileName() != null ? imageFile.getOriginalFileName() : imageFile.getImageFileName(),
                    resolveContentType(imageFile),
                    content
            );
        } catch (IOException e) {
            throw new ApiException("Файл не знайдено у сховищі", HttpStatus.NOT_FOUND);
        }
    }

    private void validateAccess(ImageFile imageFile, User currentUser) {
        if (hospitalAccessPolicy.isGlobalAdmin(currentUser)) {
            return;
        }
        if (imageFile.getTreatment() != null
                && ((imageFile.getTreatment().getPatient() != null
                && Objects.equals(imageFile.getTreatment().getPatient().getUserId(), currentUser.getUserId()))
                || (imageFile.getTreatment().getPrimaryDoctor() != null
                && Objects.equals(imageFile.getTreatment().getPrimaryDoctor().getUserId(), currentUser.getUserId())))) {
            return;
        }
        if (imageFile.getHospital() != null) {
            hospitalAccessPolicy.requireHospitalAccess(currentUser, imageFile.getHospital());
            return;
        }
        if (imageFile.getUploadedBy() != null
                && Objects.equals(imageFile.getUploadedBy().getUserId(), currentUser.getUserId())) {
            return;
        }
        throw new ApiException("Немає доступу до цього файлу", HttpStatus.FORBIDDEN);
    }

    private String resolveContentType(ImageFile imageFile) {
        return imageFile.getImageFileType() != null && !imageFile.getImageFileType().isBlank()
                ? imageFile.getImageFileType()
                : "application/octet-stream";
    }
}
