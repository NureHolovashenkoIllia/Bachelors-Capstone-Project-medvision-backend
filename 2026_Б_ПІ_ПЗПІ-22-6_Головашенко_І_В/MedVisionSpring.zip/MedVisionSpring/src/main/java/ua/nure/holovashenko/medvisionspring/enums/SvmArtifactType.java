package ua.nure.holovashenko.medvisionspring.enums;

public enum SvmArtifactType {
    MODEL,
    METRICS,
    CONFUSION_MATRIX
}
