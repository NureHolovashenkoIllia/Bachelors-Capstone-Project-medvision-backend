package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.DatasetLabelSource;

import java.time.LocalDateTime;

@Entity
@Table(name = "dataset_item", uniqueConstraints = @UniqueConstraint(columnNames = {"dataset_id", "image_file_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DatasetItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dataset_item_id")
    private Long datasetItemId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "dataset_id", nullable = false)
    private ResearchDataset dataset;

    @ManyToOne(optional = false)
    @JoinColumn(name = "image_file_id", nullable = false)
    private ImageFile imageFile;

    @ManyToOne
    @JoinColumn(name = "source_analysis_id")
    private ImageAnalysis sourceAnalysis;

    @Column(name = "class_label", nullable = false)
    private Integer classLabel;

    @Enumerated(EnumType.STRING)
    @Column(name = "label_source", nullable = false, length = 32)
    private DatasetLabelSource labelSource;

    @ManyToOne
    @JoinColumn(name = "reviewed_by_user_id")
    private User reviewedBy;

    @Column(name = "reviewed_at")
    private LocalDateTime reviewedAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
