package ua.nure.holovashenko.medvisionspring.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.util.email.EmailService;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class InvitationService {
    private final AccountTokenRepository tokenRepository;
    private final UserRepository userRepository;
    private final HospitalRepository hospitalRepository;
    private final DoctorRepository doctorRepository;
    private final UserHospitalMembershipRepository membershipRepository;
    private final HospitalAccessPolicy accessPolicy;
    private final SecureTokenService secureTokenService;
    private final PasswordEncoder passwordEncoder;
    private final AccountSecurityProperties properties;
    private final ObjectMapper objectMapper;
    private final AuditService auditService;
    private final EmailService emailService;

    @Transactional
    public DoctorInvitationResponse invite(DoctorInvitationRequest request, UserDetails principal) {
        User actor = userRepository.findByEmail(principal.getUsername()).orElseThrow();
        Hospital hospital = hospitalRepository.findById(request.hospitalId())
                .orElseThrow(() -> new ApiException("Hospital not found", HttpStatus.NOT_FOUND));
        accessPolicy.requireHospitalManager(actor, hospital);
        if (userRepository.existsByEmail(request.email())) {
            throw new ApiException("Email is already registered", HttpStatus.CONFLICT);
        }
        String rawToken = secureTokenService.generate();
        LocalDateTime expiresAt = LocalDateTime.now().plusHours(properties.invitationHours());
        try {
            AccountToken token = tokenRepository.save(AccountToken.builder()
                    .hospital(hospital)
                    .tokenHash(secureTokenService.hash(rawToken))
                    .purpose(AccountTokenPurpose.DOCTOR_INVITATION)
                    .targetEmail(request.email().trim().toLowerCase())
                    .payload(objectMapper.writeValueAsString(request))
                    .createdAt(LocalDateTime.now())
                    .expiresAt(expiresAt)
                    .createdBy(actor)
                    .build());
            auditService.record(actor, hospital, "DOCTOR_INVITATION_CREATED", "AccountToken",
                    token.getAccountTokenId().toString(), AuditOutcome.SUCCESS, null);
            try {
                emailService.sendDoctorInvitation(token.getTargetEmail(), request.name(), rawToken, expiresAt);
            } catch (RuntimeException e) {
                throw new ApiException("Unable to send invitation email", HttpStatus.BAD_GATEWAY);
            }
            return new DoctorInvitationResponse(token.getAccountTokenId(), rawToken, expiresAt);
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to create invitation", e);
        }
    }

    @Transactional
    public void accept(InvitationAcceptRequest request) {
        AccountToken token = validToken(request.token(), AccountTokenPurpose.DOCTOR_INVITATION);
        try {
            DoctorInvitationRequest invitation = objectMapper.readValue(token.getPayload(), DoctorInvitationRequest.class);
            if (userRepository.existsByEmail(token.getTargetEmail())) {
                throw new ApiException("Invitation is no longer valid", HttpStatus.GONE);
            }
            User user = userRepository.save(User.builder()
                    .userName(invitation.name())
                    .email(token.getTargetEmail())
                    .pw(passwordEncoder.encode(request.password()))
                    .userRole(UserRole.DOCTOR)
                    .accountStatus(UserAccountStatus.ACTIVE)
                    .credentialsChangedAt(LocalDateTime.now())
                    .build());
            doctorRepository.save(Doctor.builder()
                    .user(user)
                    .position(invitation.position())
                    .department(invitation.department())
                    .licenseNumber(invitation.licenseNumber())
                    .build());
            membershipRepository.save(UserHospitalMembership.builder()
                    .user(user)
                    .hospital(token.getHospital())
                    .hospitalRole(invitation.hospitalRole())
                    .status(MembershipStatus.ACTIVE)
                    .build());
            token.setConsumedAt(LocalDateTime.now());
            token.setUser(user);
            tokenRepository.save(token);
            auditService.record(user, token.getHospital(), "DOCTOR_INVITATION_ACCEPTED", "User",
                    user.getUserId().toString(), AuditOutcome.SUCCESS, null);
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to accept invitation", e);
        }
    }

    private AccountToken validToken(String raw, AccountTokenPurpose purpose) {
        AccountToken token = tokenRepository.findByTokenHashAndPurpose(secureTokenService.hash(raw), purpose)
                .orElseThrow(() -> new ApiException("Invalid or expired token", HttpStatus.GONE));
        if (token.getConsumedAt() != null || token.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new ApiException("Invalid or expired token", HttpStatus.GONE);
        }
        return token;
    }
}
