package ua.nure.holovashenko.medvisionspring.dto;

import java.util.Map;

public record AnalysisExplanationResponse(
        Long analysisId,
        Long modelVersionId,
        String modelVersion,
        ImageFileResponse heatmapFile,
        Map<Integer, Double> classScores,
        String featureSet
) {}
