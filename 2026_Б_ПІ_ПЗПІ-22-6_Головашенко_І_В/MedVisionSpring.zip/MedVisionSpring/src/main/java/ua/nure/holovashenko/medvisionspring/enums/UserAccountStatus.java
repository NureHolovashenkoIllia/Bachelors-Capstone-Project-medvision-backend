package ua.nure.holovashenko.medvisionspring.enums;

public enum UserAccountStatus {
    PENDING_VERIFICATION,
    ACTIVE,
    LOCKED,
    DISABLED
}
