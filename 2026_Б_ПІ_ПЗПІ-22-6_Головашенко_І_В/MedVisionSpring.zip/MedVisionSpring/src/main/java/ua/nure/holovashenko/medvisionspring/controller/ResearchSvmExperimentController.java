package ua.nure.holovashenko.medvisionspring.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.enums.SvmExperimentStatus;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelType;
import ua.nure.holovashenko.medvisionspring.service.ResearchSvmExperimentService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/research/svm-experiments")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class ResearchSvmExperimentController {
    private final ResearchSvmExperimentService service;

    @PostMapping
    public ResponseEntity<SvmExperimentDetailsResponse> create(@Valid @RequestBody SvmExperimentCreateRequest request, @AuthenticationPrincipal UserDetails principal) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request, principal));
    }

    @GetMapping
    public List<SvmExperimentDetailsResponse> list(@RequestParam(required = false) Long datasetId, @RequestParam(required = false) SvmExperimentStatus status, @RequestParam(required = false) SvmModelType modelType) {
        return service.list(datasetId, status, modelType);
    }

    @GetMapping("/{experimentId}")
    public SvmExperimentDetailsResponse get(@PathVariable Long experimentId) {
        return service.get(experimentId);
    }

    @PostMapping("/{experimentId}/run")
    public ResponseEntity<SvmExperimentDetailsResponse> run(@PathVariable Long experimentId) {
        return ResponseEntity.accepted().body(service.run(experimentId));
    }

    @GetMapping("/{experimentId}/metrics")
    public List<SvmExperimentMetricDto> metrics(@PathVariable Long experimentId) {
        return service.metrics(experimentId);
    }

    @GetMapping("/{experimentId}/confusion-matrix")
    public ConfusionMatrixResponse confusionMatrix(@PathVariable Long experimentId) {
        return service.confusionMatrix(experimentId);
    }

    @GetMapping("/compare")
    public Map<Long, List<SvmExperimentMetricDto>> compare(@RequestParam List<Long> ids) {
        return service.compare(ids);
    }
}
