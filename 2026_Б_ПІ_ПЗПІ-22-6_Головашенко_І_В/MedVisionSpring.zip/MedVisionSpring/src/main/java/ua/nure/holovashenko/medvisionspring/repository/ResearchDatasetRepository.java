package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.ResearchDataset;
import ua.nure.holovashenko.medvisionspring.enums.ResearchDatasetStatus;

import java.util.List;

public interface ResearchDatasetRepository extends JpaRepository<ResearchDataset, Long> {
    boolean existsByNameAndVersion(String name, String version);
    List<ResearchDataset> findAllByStatusOrderByCreatedAtDesc(ResearchDatasetStatus status);
    List<ResearchDataset> findAllByOrderByCreatedAtDesc();
}
