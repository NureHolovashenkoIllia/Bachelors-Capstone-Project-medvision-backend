package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

public record DatasetLabelRequest(
        @Min(0) @Max(1000) Integer classLabel,
        @Size(max = 2000) String reason
) {}
