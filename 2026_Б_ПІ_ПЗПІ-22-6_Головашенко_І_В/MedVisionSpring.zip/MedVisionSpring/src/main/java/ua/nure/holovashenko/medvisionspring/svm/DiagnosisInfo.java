package ua.nure.holovashenko.medvisionspring.svm;

public class DiagnosisInfo {
    private final String analysisDetails;
    private final String analysisDiagnosis;
    private final String treatmentRecommendations;

    public DiagnosisInfo(String analysisDetails, String analysisDiagnosis, String treatmentRecommendations) {
        this.analysisDetails = analysisDetails;
        this.analysisDiagnosis = analysisDiagnosis;
        this.treatmentRecommendations = treatmentRecommendations;
    }

    public DiagnosisInfo() {
        this.analysisDetails = "The analysis result could not be interpreted reliably.";
        this.analysisDiagnosis = "Unknown — the system could not determine a stable diagnosis class.";
        this.treatmentRecommendations = "Repeat the analysis or request manual clinical review.";
    }

    public String getAnalysisDetails() {
        return analysisDetails;
    }

    public String getAnalysisDiagnosis() {
        return analysisDiagnosis;
    }

    public String getTreatmentRecommendations() {
        return treatmentRecommendations;
    }
}
