package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.DatasetLabelSource;
import ua.nure.holovashenko.medvisionspring.enums.DatasetSplit;

import java.time.LocalDateTime;

public record DatasetItemResponse(
        Long itemId,
        Long datasetId,
        Long imageFileId,
        Long sourceAnalysisId,
        Integer classLabel,
        DatasetLabelSource labelSource,
        DatasetSplit split,
        Long reviewedByUserId,
        LocalDateTime reviewedAt
) {}
