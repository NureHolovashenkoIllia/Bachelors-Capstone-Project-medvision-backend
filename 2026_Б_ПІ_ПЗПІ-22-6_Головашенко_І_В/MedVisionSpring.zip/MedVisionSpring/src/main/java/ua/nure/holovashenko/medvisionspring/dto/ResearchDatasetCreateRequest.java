package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ResearchDatasetCreateRequest(
        @NotBlank @Size(max = 255) String name,
        @NotBlank @Size(max = 64) String version,
        @Size(max = 5000) String description
) {}
