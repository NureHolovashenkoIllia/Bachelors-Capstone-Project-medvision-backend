package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.DatasetSplit;

import java.time.LocalDateTime;

@Entity
@Table(name = "dataset_split_assignment")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DatasetSplitAssignment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "split_assignment_id")
    private Long splitAssignmentId;

    @OneToOne(optional = false)
    @JoinColumn(name = "dataset_item_id", nullable = false, unique = true)
    private DatasetItem datasetItem;

    @Enumerated(EnumType.STRING)
    @Column(name = "dataset_split", nullable = false, length = 32)
    private DatasetSplit datasetSplit;

    @Column(nullable = false)
    private Long seed;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
