package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ua.nure.holovashenko.medvisionspring.entity.AnalysisJob;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "medvision.analysis.worker-enabled", havingValue = "true", matchIfMissing = true)
public class AnalysisJobWorker {
    private final AnalysisJobService analysisJobService;
    private final DoctorAnalysisService doctorAnalysisService;

    @Scheduled(fixedDelayString = "${medvision.analysis.worker-delay-ms:2000}")
    public void processNext() {
        AnalysisJob job = analysisJobService.claimNext();
        if (job != null) doctorAnalysisService.processQueuedJob(job.getAnalysisJobId());
    }
}
