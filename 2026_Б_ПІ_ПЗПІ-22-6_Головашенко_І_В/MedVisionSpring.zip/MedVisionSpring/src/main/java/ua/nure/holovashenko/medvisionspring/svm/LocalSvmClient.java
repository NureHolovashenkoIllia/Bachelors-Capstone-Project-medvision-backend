package ua.nure.holovashenko.medvisionspring.svm;

import lombok.RequiredArgsConstructor;
import org.bytedeco.opencv.opencv_core.Mat;
import org.springframework.stereotype.Component;
import org.springframework.http.HttpStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;

import static ua.nure.holovashenko.medvisionspring.svm.SvmService.CLASS_LABELS;

@Component
@RequiredArgsConstructor
public class LocalSvmClient implements SvmClient {

    private final SvmService svmService;

    @Override
    public SvmClassificationResult classify(SvmClassificationRequest request) {
        int prediction = request.modelFile() == null
                ? svmService.classify(request.imageFile(), false)
                : svmService.classify(request.imageFile(), request.modelFile());
        ModelMetrics metrics = request.modelMetrics() != null ? request.modelMetrics() : loadMetrics();
        MetricsCalculator.ClassMetrics classMetrics = metrics.perClassMetrics().get(prediction);
        DiagnosisInfo diagnosisInfo = CLASS_LABELS.getOrDefault(prediction, new DiagnosisInfo());
        Mat heatmap = request.generateHeatmap()
                ? svmService.generateHeatmap(request.imageFile(), true)
                : null;

        return new SvmClassificationResult(prediction, diagnosisInfo, metrics, classMetrics, heatmap);
    }

    private ModelMetrics loadMetrics() {
        ModelMetrics metrics = svmService.loadMetrics("svm-models/full_metrics.json");
        if (metrics.perClassMetrics() != null && !metrics.perClassMetrics().isEmpty()) {
            return metrics;
        }
        throw new ApiException("MODEL_METRICS_UNAVAILABLE", HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
