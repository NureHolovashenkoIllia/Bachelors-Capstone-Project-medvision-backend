package ua.nure.holovashenko.medvisionspring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "medvision.frontend")
public record FrontendProperties(String resetPasswordUrl, String acceptInvitationUrl) {
}
