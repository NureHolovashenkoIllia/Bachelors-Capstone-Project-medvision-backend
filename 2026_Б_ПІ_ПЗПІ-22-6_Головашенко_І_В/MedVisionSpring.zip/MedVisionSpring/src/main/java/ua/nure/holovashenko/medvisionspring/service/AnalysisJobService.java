package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.MDC;
import ua.nure.holovashenko.medvisionspring.dto.AnalysisJobResponse;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisJobStatus;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.AnalysisJobRepository;
import ua.nure.holovashenko.medvisionspring.repository.HospitalRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import ua.nure.holovashenko.medvisionspring.entity.SvmModelVersion;

@Service
@RequiredArgsConstructor
public class AnalysisJobService {

    private final AnalysisJobRepository analysisJobRepository;
    private final HospitalRepository hospitalRepository;
    private final UserRepository userRepository;
    private final HospitalAccessPolicy accessPolicy;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AnalysisJob createProcessingJob(Hospital hospital, Treatment treatment, User requestedBy, String requestPayload) {
        return analysisJobRepository.save(AnalysisJob.builder()
                .hospital(hospital)
                .treatment(treatment)
                .requestedBy(requestedBy)
                .status(AnalysisJobStatus.PROCESSING)
                .requestPayload(requestPayload)
                .startedAt(LocalDateTime.now())
                .createdAt(LocalDateTime.now())
                .attemptCount(1)
                .correlationId(MDC.get("correlationId"))
                .build());
    }

    @Transactional
    public AnalysisJob createPendingJob(Hospital hospital, Treatment treatment, User requestedBy, ImageFile inputFile, SvmModelVersion modelVersion, String requestPayload) {
        return analysisJobRepository.save(AnalysisJob.builder().hospital(hospital).treatment(treatment).requestedBy(requestedBy)
                .inputFile(inputFile).modelVersion(modelVersion).status(AnalysisJobStatus.PENDING).requestPayload(requestPayload)
                .attemptCount(0).correlationId(MDC.get("correlationId")).build());
    }

    @Transactional
    public AnalysisJob claimNext() {
        List<AnalysisJob> jobs = analysisJobRepository.findClaimable(LocalDateTime.now(), PageRequest.of(0, 1));
        if (jobs.isEmpty()) return null;
        AnalysisJob job = jobs.getFirst();
        job.setStatus(AnalysisJobStatus.PROCESSING);
        job.setStartedAt(LocalDateTime.now());
        job.setFinishedAt(null);
        job.setErrorMessage(null);
        job.setAttemptCount(job.getAttemptCount() + 1);
        return analysisJobRepository.save(job);
    }

    @Transactional
    public AnalysisJobResponse retry(Long hospitalId, Long jobId, UserDetails principal) {
        AnalysisJob job = requireAccessible(hospitalId, jobId, principal);
        if (job.getStatus() != AnalysisJobStatus.FAILED) throw new ApiException("Only failed jobs can be retried", HttpStatus.CONFLICT);
        if (job.getAttemptCount() >= 3) throw new ApiException("Retry limit reached", HttpStatus.CONFLICT);
        job.setStatus(AnalysisJobStatus.PENDING);
        job.setNextAttemptAt(LocalDateTime.now());
        job.setErrorMessage(null);
        job.setFinishedAt(null);
        return mapToResponse(analysisJobRepository.save(job));
    }

    @Transactional(readOnly = true)
    public List<AnalysisJobResponse> list(Long hospitalId, Long treatmentId, AnalysisJobStatus status, UserDetails principal) {
        User currentUser = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));
        Hospital hospital = hospitalRepository.findById(hospitalId).orElseThrow(() -> new ApiException("Лікарню не знайдено", HttpStatus.NOT_FOUND));
        accessPolicy.requireHospitalAccess(currentUser, hospital);
        List<AnalysisJob> jobs = analysisJobRepository.findAllByHospitalOrderByCreatedAtDesc(hospital);
        return jobs.stream().filter(job -> treatmentId == null || job.getTreatment() != null && treatmentId.equals(job.getTreatment().getTreatmentId()))
                .filter(job -> status == null || job.getStatus() == status).map(this::mapToResponse).toList();
    }

    @Transactional
    public AnalysisJob completeJob(AnalysisJob job, ImageAnalysis analysis, String responsePayload) {
        AnalysisJob managedJob = getJobEntity(job);
        managedJob.setImageAnalysis(analysis);
        managedJob.setStatus(AnalysisJobStatus.COMPLETED);
        managedJob.setResponsePayload(responsePayload);
        managedJob.setFinishedAt(LocalDateTime.now());
        return analysisJobRepository.save(managedJob);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AnalysisJob failJob(AnalysisJob job, String errorMessage) {
        AnalysisJob managedJob = getJobEntity(job);
        managedJob.setImageAnalysis(null);
        managedJob.setStatus(AnalysisJobStatus.FAILED);
        managedJob.setErrorMessage(errorMessage);
        managedJob.setFinishedAt(LocalDateTime.now());
        return analysisJobRepository.save(managedJob);
    }

    public AnalysisJobResponse getJob(Long hospitalId, Long jobId, UserDetails userDetails) {
        return mapToResponse(requireAccessible(hospitalId, jobId, userDetails));
    }

    private AnalysisJob requireAccessible(Long hospitalId, Long jobId, UserDetails userDetails) {
        User currentUser = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ApiException("Користувача не знайдено", HttpStatus.NOT_FOUND));
        Hospital hospital = hospitalRepository.findById(hospitalId)
                .orElseThrow(() -> new ApiException("Лікарню не знайдено", HttpStatus.NOT_FOUND));
        accessPolicy.requireHospitalAccess(currentUser, hospital);

        AnalysisJob job = analysisJobRepository.findByAnalysisJobIdAndHospital(jobId, hospital)
                .orElseThrow(() -> new ApiException("Job аналізу не знайдено", HttpStatus.NOT_FOUND));

        return job;
    }

    public AnalysisJobResponse mapToResponse(AnalysisJob job) {
        return AnalysisJobResponse.builder()
                .jobId(job.getAnalysisJobId())
                .analysisId(job.getImageAnalysis() != null ? job.getImageAnalysis().getImageAnalysisId() : null)
                .hospitalId(job.getHospital() != null ? job.getHospital().getHospitalId() : null)
                .treatmentId(job.getTreatment() != null ? job.getTreatment().getTreatmentId() : null)
                .modelVersionId(job.getModelVersion() != null ? job.getModelVersion().getModelVersionId() : null)
                .status(job.getStatus())
                .errorMessage(job.getErrorMessage())
                .attemptCount(job.getAttemptCount())
                .correlationId(job.getCorrelationId())
                .startedAt(job.getStartedAt())
                .finishedAt(job.getFinishedAt())
                .createdAt(job.getCreatedAt())
                .build();
    }

    private AnalysisJob getJobEntity(AnalysisJob job) {
        if (job == null || job.getAnalysisJobId() == null) {
            throw new ApiException("Job аналізу не знайдено", HttpStatus.NOT_FOUND);
        }
        return analysisJobRepository.findById(job.getAnalysisJobId())
                .orElseThrow(() -> new ApiException("Job аналізу не знайдено", HttpStatus.NOT_FOUND));
    }

    @Transactional(readOnly = true)
    public AnalysisJob getForWorker(Long jobId) {
        return analysisJobRepository.findById(jobId).orElseThrow(() -> new ApiException("Analysis job not found", HttpStatus.NOT_FOUND));
    }
}
