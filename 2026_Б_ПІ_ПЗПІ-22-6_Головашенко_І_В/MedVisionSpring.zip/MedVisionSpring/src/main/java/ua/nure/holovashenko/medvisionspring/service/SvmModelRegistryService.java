package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.dto.SvmModelRegisterRequest;
import ua.nure.holovashenko.medvisionspring.dto.SvmModelMetricResponse;
import ua.nure.holovashenko.medvisionspring.dto.SvmModelVersionResponse;
import ua.nure.holovashenko.medvisionspring.entity.SvmModelMetric;
import ua.nure.holovashenko.medvisionspring.entity.SvmModelVersion;
import ua.nure.holovashenko.medvisionspring.enums.DatasetSplit;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelStatus;
import ua.nure.holovashenko.medvisionspring.enums.SvmModelType;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.SvmModelMetricRepository;
import ua.nure.holovashenko.medvisionspring.repository.SvmModelVersionRepository;
import ua.nure.holovashenko.medvisionspring.repository.SvmExperimentArtifactRepository;
import ua.nure.holovashenko.medvisionspring.repository.SvmExperimentMetricRepository;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;
import ua.nure.holovashenko.medvisionspring.enums.SvmArtifactType;
import ua.nure.holovashenko.medvisionspring.enums.SvmExperimentStatus;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperiment;
import ua.nure.holovashenko.medvisionspring.entity.ResearchDataset;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperimentArtifact;
import java.time.LocalDateTime;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.HashMap;
import ua.nure.holovashenko.medvisionspring.svm.ModelMetrics;
import ua.nure.holovashenko.medvisionspring.svm.MetricsCalculator;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SvmModelRegistryService {

    private final SvmModelVersionRepository modelVersionRepository;
    private final SvmModelMetricRepository metricRepository;
    private final SvmExperimentArtifactRepository artifactRepository;
    private final SvmExperimentMetricRepository experimentMetricRepository;
    private final ResearchSvmExperimentService experimentService;
    private final BlobStorageService blobStorageService;

    public SvmModelVersion getActiveFullImageModel() {
        return modelVersionRepository.findFirstByModelTypeAndStatusOrderByActivatedAtDesc(
                        SvmModelType.FULL_IMAGE,
                        SvmModelStatus.ACTIVE
                )
                .orElseThrow(() -> new ApiException("Активну SVM-модель не знайдено", HttpStatus.INTERNAL_SERVER_ERROR));
    }

    public SvmModelVersion resolveFullImageModel(Long modelId) {
        if (modelId == null) return getActiveFullImageModel();
        SvmModelVersion model = requireModel(modelId);
        if (model.getModelType() != SvmModelType.FULL_IMAGE || (model.getStatus() != SvmModelStatus.ACTIVE && model.getStatus() != SvmModelStatus.CANDIDATE)) {
            throw new ApiException("Requested model is not an available full-image model", HttpStatus.CONFLICT);
        }
        verifyArtifact(model);
        return model;
    }

    public ModelMetrics runtimeMetrics(SvmModelVersion model) {
        List<SvmModelMetric> values = metricRepository.findAllByModelVersionAndDatasetSplit(model, DatasetSplit.TEST);
        double accuracy = values.stream().filter(value -> "ALL".equals(value.getClassLabel()) && "accuracy".equals(value.getMetricName()))
                .mapToDouble(SvmModelMetric::getMetricValue).findFirst().orElse(0.0);
        Map<Integer, MetricsCalculator.ClassMetrics> classes = new HashMap<>();
        values.stream().filter(value -> !"ALL".equals(value.getClassLabel())).map(SvmModelMetric::getClassLabel).distinct().forEach(label -> {
            int classLabel = Integer.parseInt(label);
            double precision = metric(values, label, "precision");
            double recall = metric(values, label, "recall");
            double f1 = metric(values, label, "f1");
            classes.put(classLabel, new MetricsCalculator.ClassMetrics(precision, recall, f1));
        });
        return new ModelMetrics(accuracy, new int[0][0], classes);
    }

    private double metric(List<SvmModelMetric> values, String label, String name) {
        return values.stream().filter(value -> label.equals(value.getClassLabel()) && name.equals(value.getMetricName()))
                .mapToDouble(SvmModelMetric::getMetricValue).findFirst().orElse(0.0);
    }

    @Transactional
    public SvmModelVersionResponse register(SvmModelRegisterRequest request) {
        if (modelVersionRepository.existsByVersion(request.version())) throw new ApiException("Model version already exists", HttpStatus.CONFLICT);
        SvmExperiment experiment = experimentService.requireCompleted(request.experimentId());
        SvmExperimentArtifact modelArtifact = artifactRepository.findByExperimentAndArtifactType(experiment, SvmArtifactType.MODEL)
                .orElseThrow(() -> new ApiException("Model artifact not found", HttpStatus.UNPROCESSABLE_ENTITY));
        SvmExperimentArtifact metricsArtifact = artifactRepository.findByExperimentAndArtifactType(experiment, SvmArtifactType.METRICS)
                .orElseThrow(() -> new ApiException("Metrics artifact not found", HttpStatus.UNPROCESSABLE_ENTITY));
        ResearchDataset dataset = experiment.getDataset();
        SvmModelVersion model = modelVersionRepository.save(SvmModelVersion.builder()
                .experiment(experiment).name(request.name()).version(request.version()).modelType(experiment.getModelType())
                .kernelType(experiment.getKernelType()).multiclassStrategy(experiment.getMulticlassStrategy())
                .featureSet(experiment.getFeatureSet()).imageWidth(224).imageHeight(224)
                .patchSize(experiment.getModelType() == SvmModelType.PATCH_BASED ? 64 : null)
                .stepSize(experiment.getModelType() == SvmModelType.PATCH_BASED ? 32 : null)
                .datasetName(dataset.getName() + ":" + dataset.getVersion())
                .storageUri(modelArtifact.getStorageUri()).metricsUri(metricsArtifact.getStorageUri())
                .artifactChecksum(modelArtifact.getChecksumSha256()).artifactSizeBytes(modelArtifact.getSizeBytes())
                .status(SvmModelStatus.CANDIDATE).trainedAt(experiment.getFinishedAt()).build());
        experimentMetricRepository.findAllByExperimentOrderByDatasetSplitAscClassLabelAscMetricNameAsc(experiment).forEach(source ->
                metricRepository.save(SvmModelMetric.builder().modelVersion(model).datasetSplit(source.getDatasetSplit())
                        .classLabel(source.getClassLabel()).metricName(source.getMetricName()).metricValue(source.getMetricValue().doubleValue()).build()));
        return mapModel(model);
    }

    @Transactional(readOnly = true)
    public SvmModelVersionResponse getActive(SvmModelType modelType) {
        return mapModel(modelVersionRepository.findFirstByModelTypeAndStatusOrderByActivatedAtDesc(modelType, SvmModelStatus.ACTIVE)
                .orElseThrow(() -> new ApiException("Active SVM model not found", HttpStatus.NOT_FOUND)));
    }

    @Transactional
    public SvmModelVersionResponse activate(Long modelId) {
        SvmModelVersion candidate = requireModel(modelId);
        if (candidate.getStatus() != SvmModelStatus.CANDIDATE && candidate.getStatus() != SvmModelStatus.ACTIVE) throw new ApiException("Only candidate models can be activated", HttpStatus.CONFLICT);
        verifyArtifact(candidate);
        if (candidate.getMetricsUri() == null || metricRepository.findAllByModelVersion(candidate).isEmpty()) throw new ApiException("Model metrics are unavailable", HttpStatus.UNPROCESSABLE_ENTITY);
        modelVersionRepository.findAllByModelTypeForUpdate(candidate.getModelType()).stream()
                .filter(active -> active.getStatus() == SvmModelStatus.ACTIVE && !active.getModelVersionId().equals(modelId))
                .forEach(active -> { active.setStatus(SvmModelStatus.ARCHIVED); modelVersionRepository.save(active); });
        candidate.setStatus(SvmModelStatus.ACTIVE);
        candidate.setActivatedAt(LocalDateTime.now());
        return mapModel(modelVersionRepository.save(candidate));
    }

    @Transactional
    public SvmModelVersionResponse archive(Long modelId) {
        SvmModelVersion model = requireModel(modelId);
        if (model.getStatus() == SvmModelStatus.ACTIVE) throw new ApiException("Active model cannot be archived", HttpStatus.CONFLICT);
        model.setStatus(SvmModelStatus.ARCHIVED);
        return mapModel(modelVersionRepository.save(model));
    }

    private SvmModelVersion requireModel(Long id) {
        return modelVersionRepository.findById(id).orElseThrow(() -> new ApiException("SVM model version not found", HttpStatus.NOT_FOUND));
    }

    private void verifyArtifact(SvmModelVersion model) {
        try {
            byte[] data = model.getStorageUri().contains("://") || model.getStorageUri().startsWith("file:")
                    ? blobStorageService.downloadFileFromBlobUrl(model.getStorageUri())
                    : blobStorageService.downloadFileByName(model.getStorageUri());
            String checksum = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
            if (model.getArtifactSizeBytes() != null && model.getArtifactSizeBytes() != data.length) throw new ApiException("Model artifact size mismatch", HttpStatus.SERVICE_UNAVAILABLE);
            if (model.getArtifactChecksum() != null && !model.getArtifactChecksum().equalsIgnoreCase(checksum)) throw new ApiException("Model artifact checksum mismatch", HttpStatus.SERVICE_UNAVAILABLE);
        } catch (ApiException exception) { throw exception; }
        catch (Exception exception) { throw new ApiException("Model artifact is unavailable", HttpStatus.SERVICE_UNAVAILABLE); }
    }

    public List<SvmModelVersionResponse> getModels() {
        return modelVersionRepository.findAll().stream()
                .map(this::mapModel)
                .toList();
    }

    public List<SvmModelMetricResponse> getMetrics(Long modelVersionId, DatasetSplit split) {
        SvmModelVersion modelVersion = modelVersionRepository.findById(modelVersionId)
                .orElseThrow(() -> new ApiException("Версію SVM-моделі не знайдено", HttpStatus.NOT_FOUND));

        List<SvmModelMetric> metrics = split == null
                ? metricRepository.findAllByModelVersion(modelVersion)
                : metricRepository.findAllByModelVersionAndDatasetSplit(modelVersion, split);

        return metrics.stream()
                .map(this::mapMetric)
                .toList();
    }

    private SvmModelVersionResponse mapModel(SvmModelVersion model) {
        return SvmModelVersionResponse.builder()
                .modelVersionId(model.getModelVersionId())
                .experimentId(model.getExperiment() != null ? model.getExperiment().getExperimentId() : null)
                .name(model.getName())
                .version(model.getVersion())
                .modelType(model.getModelType())
                .kernelType(model.getKernelType())
                .multiclassStrategy(model.getMulticlassStrategy())
                .featureSet(model.getFeatureSet())
                .imageWidth(model.getImageWidth())
                .imageHeight(model.getImageHeight())
                .patchSize(model.getPatchSize())
                .stepSize(model.getStepSize())
                .datasetName(model.getDatasetName())
                .storageUri(model.getStorageUri())
                .metricsUri(model.getMetricsUri())
                .artifactChecksum(model.getArtifactChecksum())
                .artifactSizeBytes(model.getArtifactSizeBytes())
                .status(model.getStatus())
                .trainedAt(model.getTrainedAt())
                .activatedAt(model.getActivatedAt())
                .build();
    }

    private SvmModelMetricResponse mapMetric(SvmModelMetric metric) {
        return SvmModelMetricResponse.builder()
                .metricId(metric.getMetricId())
                .modelVersionId(metric.getModelVersion().getModelVersionId())
                .datasetSplit(metric.getDatasetSplit())
                .classLabel(metric.getClassLabel())
                .metricName(metric.getMetricName())
                .metricValue(metric.getMetricValue())
                .build();
    }
}
