package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperiment;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperimentMetric;

import java.util.List;

public interface SvmExperimentMetricRepository extends JpaRepository<SvmExperimentMetric, Long> {
    List<SvmExperimentMetric> findAllByExperimentOrderByDatasetSplitAscClassLabelAscMetricNameAsc(SvmExperiment experiment);
    void deleteAllByExperiment(SvmExperiment experiment);
}
