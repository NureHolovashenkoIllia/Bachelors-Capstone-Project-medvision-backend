package ua.nure.holovashenko.medvisionspring.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisReviewDecision;

public record AnalysisReviewRequest(
        @NotNull AnalysisReviewDecision decision,
        @Min(0) @Max(1000) Integer correctedClass,
        @Size(max = 5000) String comment
) {}
