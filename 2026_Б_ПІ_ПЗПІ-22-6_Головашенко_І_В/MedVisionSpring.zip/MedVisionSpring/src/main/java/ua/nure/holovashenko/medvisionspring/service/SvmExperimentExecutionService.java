package ua.nure.holovashenko.medvisionspring.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bytedeco.opencv.global.opencv_core;
import org.bytedeco.opencv.global.opencv_ml;
import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.MatVector;
import org.bytedeco.opencv.opencv_ml.SVM;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;
import ua.nure.holovashenko.medvisionspring.svm.*;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class SvmExperimentExecutionService {
    private final SvmExperimentRepository experimentRepository;
    private final DatasetSplitAssignmentRepository splitRepository;
    private final SvmExperimentMetricRepository metricRepository;
    private final SvmExperimentArtifactRepository artifactRepository;
    private final BlobStorageService blobStorageService;
    private final ImagePatchExtractor patchExtractor;
    private final MetricsCalculator metricsCalculator;
    private final ObjectMapper objectMapper;

    @Async("researchExecutor")
    @Transactional
    public void execute(Long experimentId) {
        List<File> temporaryFiles = new ArrayList<>();
        try {
            SvmExperiment experiment = experimentRepository.findById(experimentId).orElseThrow();
            Map<DatasetSplit, LoadedSplit> splits = loadSplits(experiment.getDataset(), temporaryFiles);
            LoadedSplit train = requireSplit(splits, DatasetSplit.TRAIN);
            LoadedSplit validation = requireSplit(splits, DatasetSplit.VALIDATION);
            LoadedSplit test = requireSplit(splits, DatasetSplit.TEST);
            SVM model = trainModel(experiment, train);
            Evaluation validationEvaluation = evaluate(model, experiment.getModelType(), validation);
            Evaluation testEvaluation = evaluate(model, experiment.getModelType(), test);

            File modelFile = File.createTempFile("svm-experiment-", ".xml");
            temporaryFiles.add(modelFile);
            model.save(modelFile.getAbsolutePath());

            Map<String, Object> metricsDocument = Map.of(
                    "validation", validationEvaluation.metrics(),
                    "test", testEvaluation.metrics(),
                    "seed", experiment.getSeed(),
                    "datasetId", experiment.getDataset().getDatasetId()
            );
            File metricsFile = writeJson("experiment-metrics-", metricsDocument, temporaryFiles);
            File confusionFile = writeJson("confusion-matrix-", Map.of(
                    "labels", testEvaluation.labels(),
                    "matrix", testEvaluation.metrics().confusionMatrix()
            ), temporaryFiles);

            String prefix = "research/experiments/" + experimentId + "/";
            ArtifactData modelArtifact = upload(modelFile, prefix + "model.xml", "application/xml");
            ArtifactData metricsArtifact = upload(metricsFile, prefix + "metrics.json", "application/json");
            ArtifactData confusionArtifact = upload(confusionFile, prefix + "confusion-matrix.json", "application/json");
            complete(experimentId, validationEvaluation.metrics(), testEvaluation.metrics(), modelArtifact, metricsArtifact, confusionArtifact);
        } catch (Exception exception) {
            log.error("SVM experiment {} failed", experimentId, exception);
            fail(experimentId, exception.getMessage());
        } finally {
            temporaryFiles.forEach(File::delete);
        }
    }

    private Map<DatasetSplit, LoadedSplit> loadSplits(ResearchDataset dataset, List<File> temporaryFiles) throws Exception {
        Map<DatasetSplit, LoadedSplit> result = new EnumMap<>(DatasetSplit.class);
        for (DatasetSplit split : List.of(DatasetSplit.TRAIN, DatasetSplit.VALIDATION, DatasetSplit.TEST)) {
            List<File> files = new ArrayList<>();
            List<Integer> labels = new ArrayList<>();
            for (DatasetSplitAssignment assignment : splitRepository.findAllByDatasetAndSplit(dataset, split)) {
                ImageFile imageFile = assignment.getDatasetItem().getImageFile();
                File file = File.createTempFile("dataset-item-", imageFile.getImageFileType().contains("jpeg") ? ".jpg" : ".png");
                Files.write(file.toPath(), readImageFile(imageFile));
                files.add(file);
                temporaryFiles.add(file);
                labels.add(assignment.getDatasetItem().getClassLabel());
            }
            result.put(split, new LoadedSplit(files, labels));
        }
        return result;
    }

    byte[] readImageFile(ImageFile imageFile) throws Exception {
        if (imageFile.getStorageKey() != null && !imageFile.getStorageKey().isBlank()) {
            return blobStorageService.downloadFileByName(imageFile.getStorageKey());
        }
        return blobStorageService.downloadFileFromBlobUrl(imageFile.getImageFileUrl());
    }

    private LoadedSplit requireSplit(Map<DatasetSplit, LoadedSplit> splits, DatasetSplit split) {
        LoadedSplit loaded = splits.get(split);
        if (loaded == null || loaded.files().isEmpty()) throw new IllegalStateException(split + " split is empty");
        return loaded;
    }

    private SVM trainModel(SvmExperiment experiment, LoadedSplit train) {
        FeatureData data = features(train, experiment.getModelType(), true);
        Mat labels = new Mat(data.labels().size(), 1, opencv_core.CV_32S);
        for (int i = 0; i < data.labels().size(); i++) labels.ptr(i, 0).putInt(data.labels().get(i));
        Mat trainingData = new Mat();
        opencv_core.vconcat(new MatVector(data.features().toArray(new Mat[0])), trainingData);
        SVM model = SVM.create();
        model.setType(SVM.C_SVC);
        model.setKernel(switch (experiment.getKernelType()) {
            case LINEAR -> SVM.LINEAR;
            case POLYNOMIAL -> SVM.POLY;
            case RBF -> SVM.RBF;
        });
        model.setC(experiment.getCValue().doubleValue());
        if (experiment.getGammaValue() != null) model.setGamma(experiment.getGammaValue().doubleValue());
        if (!model.train(trainingData, opencv_ml.ROW_SAMPLE, labels)) throw new IllegalStateException("SVM training failed");
        return model;
    }

    private Evaluation evaluate(SVM model, SvmModelType modelType, LoadedSplit split) {
        List<Integer> predictions = new ArrayList<>();
        for (File file : split.files()) {
            if (modelType == SvmModelType.FULL_IMAGE) {
                predictions.add((int) model.predict(fullImageFeature(file)));
            } else {
                List<FeatureLabelPair> patches = patchExtractor.extract(file, -1, true);
                Map<Integer, Integer> counts = new HashMap<>();
                for (FeatureLabelPair patch : patches) {
                    int predicted = (int) model.predict(patch.features());
                    counts.merge(predicted, 1, Integer::sum);
                }
                predictions.add(counts.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(-1));
            }
        }
        int classCount = Math.max(split.labels().stream().mapToInt(Integer::intValue).max().orElse(0), predictions.stream().mapToInt(Integer::intValue).max().orElse(0)) + 1;
        int[][] matrix = metricsCalculator.computeConfusionMatrix(split.labels(), predictions, classCount);
        ModelMetrics metrics = new ModelMetrics(metricsCalculator.computeAccuracy(split.labels(), predictions), matrix, metricsCalculator.computePerClassMetrics(matrix));
        return new Evaluation(new ArrayList<>(new TreeSet<>(split.labels())), metrics);
    }

    private FeatureData features(LoadedSplit split, SvmModelType modelType, boolean training) {
        List<Mat> features = new ArrayList<>();
        List<Integer> labels = new ArrayList<>();
        for (int i = 0; i < split.files().size(); i++) {
            if (modelType == SvmModelType.FULL_IMAGE) {
                features.add(fullImageFeature(split.files().get(i)));
                labels.add(split.labels().get(i));
            } else {
                for (FeatureLabelPair patch : patchExtractor.extract(split.files().get(i), split.labels().get(i), training)) {
                    features.add(patch.features());
                    labels.add(patch.label());
                }
            }
        }
        return new FeatureData(features, labels);
    }

    private Mat fullImageFeature(File file) {
        Mat image = ImageUtils.loadAndResizeImage(file.getAbsolutePath());
        if (image.empty()) throw new IllegalArgumentException("Invalid image: " + file.getName());
        Mat feature = image.reshape(1, 1);
        feature.convertTo(feature, opencv_core.CV_32F);
        return feature;
    }

    private File writeJson(String prefix, Object value, List<File> temporaryFiles) throws Exception {
        File file = File.createTempFile(prefix, ".json");
        objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, value);
        temporaryFiles.add(file);
        return file;
    }

    private ArtifactData upload(File file, String key, String contentType) throws Exception {
        byte[] bytes = Files.readAllBytes(file.toPath());
        String checksum = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        return new ArtifactData(blobStorageService.uploadFile(file, key, contentType), checksum, (long) bytes.length);
    }

    @Transactional
    protected void complete(Long id, ModelMetrics validation, ModelMetrics test, ArtifactData model, ArtifactData metrics, ArtifactData confusion) {
        SvmExperiment experiment = experimentRepository.findById(id).orElseThrow();
        metricRepository.deleteAllByExperiment(experiment);
        artifactRepository.deleteAllByExperiment(experiment);
        saveMetrics(experiment, DatasetSplit.VALIDATION, validation);
        saveMetrics(experiment, DatasetSplit.TEST, test);
        saveArtifact(experiment, SvmArtifactType.MODEL, model);
        saveArtifact(experiment, SvmArtifactType.METRICS, metrics);
        saveArtifact(experiment, SvmArtifactType.CONFUSION_MATRIX, confusion);
        experiment.setStatus(SvmExperimentStatus.COMPLETED);
        experiment.setFinishedAt(LocalDateTime.now());
        experiment.setFailureReason(null);
        experimentRepository.save(experiment);
    }

    private void saveMetrics(SvmExperiment experiment, DatasetSplit split, ModelMetrics metrics) {
        metricRepository.save(SvmExperimentMetric.builder().experiment(experiment).datasetSplit(split).classLabel("ALL").metricName("accuracy").metricValue(BigDecimal.valueOf(metrics.accuracy())).build());
        metrics.perClassMetrics().forEach((label, values) -> {
            metricRepository.save(SvmExperimentMetric.builder().experiment(experiment).datasetSplit(split).classLabel(label.toString()).metricName("precision").metricValue(BigDecimal.valueOf(values.precision())).build());
            metricRepository.save(SvmExperimentMetric.builder().experiment(experiment).datasetSplit(split).classLabel(label.toString()).metricName("recall").metricValue(BigDecimal.valueOf(values.recall())).build());
            metricRepository.save(SvmExperimentMetric.builder().experiment(experiment).datasetSplit(split).classLabel(label.toString()).metricName("f1").metricValue(BigDecimal.valueOf(values.f1())).build());
        });
    }

    private void saveArtifact(SvmExperiment experiment, SvmArtifactType type, ArtifactData data) {
        artifactRepository.save(SvmExperimentArtifact.builder().experiment(experiment).artifactType(type).storageUri(data.uri()).checksumSha256(data.checksum()).sizeBytes(data.size()).build());
    }

    @Transactional
    protected void fail(Long id, String reason) {
        experimentRepository.findById(id).ifPresent(experiment -> {
            experiment.setStatus(SvmExperimentStatus.FAILED);
            experiment.setFailureReason(reason == null ? "Experiment failed" : reason.substring(0, Math.min(reason.length(), 4000)));
            experiment.setFinishedAt(LocalDateTime.now());
            experimentRepository.save(experiment);
        });
    }

    private record LoadedSplit(List<File> files, List<Integer> labels) {}
    private record FeatureData(List<Mat> features, List<Integer> labels) {}
    private record Evaluation(List<Integer> labels, ModelMetrics metrics) {}
    private record ArtifactData(String uri, String checksum, Long size) {}
}
