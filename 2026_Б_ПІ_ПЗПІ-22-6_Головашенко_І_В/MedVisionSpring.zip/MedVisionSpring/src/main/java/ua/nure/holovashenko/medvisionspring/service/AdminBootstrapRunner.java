package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import ua.nure.holovashenko.medvisionspring.config.AdminBootstrapProperties;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.UserRole;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;

import java.util.regex.Pattern;

@Component
@RequiredArgsConstructor
public class AdminBootstrapRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(AdminBootstrapRunner.class);
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final int MINIMUM_PASSWORD_LENGTH = 12;

    private final AdminBootstrapProperties properties;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (!properties.enabled()) {
            return;
        }

        if (userRepository.existsByUserRole(UserRole.ADMIN)) {
            log.info("Administrator bootstrap skipped because an administrator already exists");
            return;
        }

        validateConfiguration();

        String email = properties.email().trim();
        if (userRepository.existsByEmail(email)) {
            throw new IllegalStateException("Administrator bootstrap email is already assigned to another user");
        }

        User administrator = new User();
        administrator.setUserName(properties.name().trim());
        administrator.setEmail(email);
        administrator.setPw(passwordEncoder.encode(properties.password()));
        administrator.setUserRole(UserRole.ADMIN);

        User savedAdministrator = userRepository.save(administrator);
        log.info("Bootstrap administrator created with id {}", savedAdministrator.getUserId());
    }

    private void validateConfiguration() {
        if (!StringUtils.hasText(properties.name())) {
            throw new IllegalStateException("MEDVISION_BOOTSTRAP_ADMIN_NAME must be set when administrator bootstrap is enabled");
        }
        if (!StringUtils.hasText(properties.email())
                || !EMAIL_PATTERN.matcher(properties.email().trim()).matches()) {
            throw new IllegalStateException("MEDVISION_BOOTSTRAP_ADMIN_EMAIL must contain a valid email address");
        }
        if (!StringUtils.hasText(properties.password())
                || properties.password().length() < MINIMUM_PASSWORD_LENGTH) {
            throw new IllegalStateException("MEDVISION_BOOTSTRAP_ADMIN_PASSWORD must contain at least 12 characters");
        }
    }
}
