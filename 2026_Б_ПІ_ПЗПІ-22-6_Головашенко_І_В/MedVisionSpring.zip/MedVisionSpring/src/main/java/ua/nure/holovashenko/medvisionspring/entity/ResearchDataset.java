package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.ResearchDatasetStatus;

import java.time.LocalDateTime;

@Entity
@Table(name = "research_dataset", uniqueConstraints = @UniqueConstraint(columnNames = {"name", "version"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResearchDataset {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dataset_id")
    private Long datasetId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, length = 64)
    private String version;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private ResearchDatasetStatus status;

    @ManyToOne(optional = false)
    @JoinColumn(name = "created_by_user_id", nullable = false)
    private User createdBy;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "frozen_at")
    private LocalDateTime frozenAt;

    @PrePersist
    void prePersist() {
        if (status == null) status = ResearchDatasetStatus.DRAFT;
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
