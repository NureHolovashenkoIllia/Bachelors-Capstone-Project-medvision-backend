package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.AnalysisReviewDecision;

import java.time.LocalDateTime;

public record AnalysisReviewResponse(
        Long reviewId,
        Long analysisId,
        AnalysisReviewDecision decision,
        Integer originalClass,
        Integer correctedClass,
        String comment,
        Long reviewedByUserId,
        LocalDateTime reviewedAt
) {}
