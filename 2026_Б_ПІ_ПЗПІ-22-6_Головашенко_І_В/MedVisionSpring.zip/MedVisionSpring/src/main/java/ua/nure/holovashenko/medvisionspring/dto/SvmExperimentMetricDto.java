package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.DatasetSplit;

import java.math.BigDecimal;

public record SvmExperimentMetricDto(
        DatasetSplit split,
        String classLabel,
        String metricName,
        BigDecimal metricValue
) {}
