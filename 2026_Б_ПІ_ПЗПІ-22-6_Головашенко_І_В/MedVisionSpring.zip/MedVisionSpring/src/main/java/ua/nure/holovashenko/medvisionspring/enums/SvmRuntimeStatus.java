package ua.nure.holovashenko.medvisionspring.enums;

public enum SvmRuntimeStatus {
    NOT_LOADED,
    LOADING,
    READY,
    FAILED
}
