package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record SvmExperimentDetailsResponse(
        Long experimentId,
        Long datasetId,
        SvmModelType modelType,
        SvmKernelType kernelType,
        BigDecimal c,
        BigDecimal gamma,
        SvmMulticlassStrategy multiclassStrategy,
        String featureSet,
        Long seed,
        SvmExperimentStatus status,
        String failureReason,
        LocalDateTime createdAt,
        LocalDateTime startedAt,
        LocalDateTime finishedAt
) {}
