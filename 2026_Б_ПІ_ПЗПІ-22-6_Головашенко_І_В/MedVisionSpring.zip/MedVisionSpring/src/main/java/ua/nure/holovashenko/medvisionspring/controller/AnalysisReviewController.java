package ua.nure.holovashenko.medvisionspring.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.service.AnalysisReviewService;

@RestController
@RequestMapping("/api/hospitals/{hospitalId}/treatments/{treatmentId}/analyses/{analysisId}")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
public class AnalysisReviewController {
    private final AnalysisReviewService service;

    @PutMapping("/review")
    public AnalysisReviewResponse review(@PathVariable Long hospitalId, @PathVariable Long treatmentId, @PathVariable Long analysisId,
            @Valid @RequestBody AnalysisReviewRequest request, @AuthenticationPrincipal UserDetails principal) {
        return service.review(hospitalId, treatmentId, analysisId, request, principal);
    }

    @GetMapping("/review")
    public AnalysisReviewResponse get(@PathVariable Long hospitalId, @PathVariable Long treatmentId, @PathVariable Long analysisId,
            @AuthenticationPrincipal UserDetails principal) {
        return service.get(hospitalId, treatmentId, analysisId, principal);
    }

    @GetMapping("/explanation")
    public AnalysisExplanationResponse explanation(@PathVariable Long hospitalId, @PathVariable Long treatmentId, @PathVariable Long analysisId,
            @AuthenticationPrincipal UserDetails principal) {
        return service.explanation(hospitalId, treatmentId, analysisId, principal);
    }
}
