package ua.nure.holovashenko.medvisionspring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "medvision.cors")
public record CorsProperties(List<String> allowedOrigins) {
}
