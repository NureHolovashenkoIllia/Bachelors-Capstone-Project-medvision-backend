package ua.nure.holovashenko.medvisionspring.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "medvision.account")
public record AccountSecurityProperties(
        int maximumFailedLogins,
        long lockDurationMinutes,
        long refreshTokenDays,
        long invitationHours,
        long passwordResetMinutes
) {
}
