package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.config.AccountSecurityProperties;
import ua.nure.holovashenko.medvisionspring.dto.AccountStatusRequest;
import ua.nure.holovashenko.medvisionspring.entity.AccountToken;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.AccountTokenRepository;
import ua.nure.holovashenko.medvisionspring.repository.UserRepository;
import ua.nure.holovashenko.medvisionspring.util.email.EmailService;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountLifecycleService {
    private final UserRepository userRepository;
    private final AccountTokenRepository tokenRepository;
    private final SecureTokenService secureTokenService;
    private final AuthSessionService sessionService;
    private final PasswordEncoder passwordEncoder;
    private final AccountSecurityProperties properties;
    private final EmailService emailService;
    private final AuditService auditService;

    @Transactional
    public void requestPasswordReset(String email) {
        userRepository.findByEmail(email.trim().toLowerCase()).ifPresent(user -> {
            String rawToken = secureTokenService.generate();
            tokenRepository.save(AccountToken.builder()
                    .user(user)
                    .tokenHash(secureTokenService.hash(rawToken))
                    .purpose(AccountTokenPurpose.PASSWORD_RESET)
                    .targetEmail(user.getEmail())
                    .createdAt(LocalDateTime.now())
                    .expiresAt(LocalDateTime.now().plusMinutes(properties.passwordResetMinutes()))
                    .build());
            try {
                emailService.sendPasswordResetToken(user.getEmail(), rawToken);
            } catch (RuntimeException e) {
                log.error("Password reset email delivery failed for user {}", user.getUserId(), e);
            }
        });
    }

    @Transactional
    public void resetPassword(String rawToken, String newPassword) {
        AccountToken token = tokenRepository.findByTokenHashAndPurpose(
                        secureTokenService.hash(rawToken), AccountTokenPurpose.PASSWORD_RESET)
                .orElseThrow(() -> new ApiException("Invalid or expired token", HttpStatus.GONE));
        if (token.getConsumedAt() != null || token.getExpiresAt().isBefore(LocalDateTime.now()) || token.getUser() == null) {
            throw new ApiException("Invalid or expired token", HttpStatus.GONE);
        }
        User user = token.getUser();
        user.setPw(passwordEncoder.encode(newPassword));
        user.setCredentialsChangedAt(LocalDateTime.now());
        user.setFailedLoginAttempts(0);
        user.setLockedUntil(null);
        user.setAccountStatus(UserAccountStatus.ACTIVE);
        token.setConsumedAt(LocalDateTime.now());
        sessionService.revokeAll(user);
        auditService.record(user, null, "PASSWORD_RESET", "User", user.getUserId().toString(), AuditOutcome.SUCCESS, null);
    }

    @Transactional
    public void updateStatus(User actor, Long userId, AccountStatusRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        if (user.getUserId().equals(actor.getUserId()) && request.status() == UserAccountStatus.DISABLED) {
            throw new ApiException("Administrator cannot disable the current account", HttpStatus.CONFLICT);
        }
        user.setAccountStatus(request.status());
        user.setFailedLoginAttempts(0);
        user.setLockedUntil(null);
        if (request.status() != UserAccountStatus.ACTIVE) {
            sessionService.revokeAll(user);
        }
        auditService.record(actor, null, "ACCOUNT_STATUS_CHANGED", "User", userId.toString(),
                AuditOutcome.SUCCESS, "status=" + request.status() + ";reason=" + request.reason());
    }
}
