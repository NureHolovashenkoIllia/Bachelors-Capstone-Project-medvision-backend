package ua.nure.holovashenko.medvisionspring.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.enums.ResearchDatasetStatus;
import ua.nure.holovashenko.medvisionspring.service.ResearchDatasetService;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/research")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class ResearchDatasetController {
    private final ResearchDatasetService service;

    @PostMapping("/datasets")
    public ResponseEntity<ResearchDatasetResponse> create(@Valid @RequestBody ResearchDatasetCreateRequest request, @AuthenticationPrincipal UserDetails principal) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request, principal));
    }

    @GetMapping("/datasets")
    public List<ResearchDatasetResponse> list(@RequestParam(required = false) ResearchDatasetStatus status) {
        return service.list(status);
    }

    @GetMapping("/datasets/{datasetId}")
    public ResearchDatasetResponse get(@PathVariable Long datasetId) {
        return service.get(datasetId);
    }

    @PostMapping(value = "/datasets/{datasetId}/items", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DatasetItemResponse> addItem(@PathVariable Long datasetId, @RequestParam MultipartFile file, @RequestParam Integer classLabel, @RequestParam(required = false) Long sourceAnalysisId, @AuthenticationPrincipal UserDetails principal) throws IOException {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.addItem(datasetId, file, classLabel, sourceAnalysisId, principal));
    }

    @PutMapping("/dataset-items/{itemId}/label")
    public DatasetItemResponse label(@PathVariable Long itemId, @Valid @RequestBody DatasetLabelRequest request, @AuthenticationPrincipal UserDetails principal) {
        return service.updateLabel(itemId, request, principal);
    }

    @PostMapping("/datasets/{datasetId}/split")
    public DatasetSplitResponse split(@PathVariable Long datasetId, @Valid @RequestBody DatasetSplitCreateRequest request) {
        return service.split(datasetId, request);
    }

    @PostMapping("/datasets/{datasetId}/freeze")
    public ResearchDatasetResponse freeze(@PathVariable Long datasetId) {
        return service.freeze(datasetId);
    }
}
