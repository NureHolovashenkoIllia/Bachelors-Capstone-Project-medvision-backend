package ua.nure.holovashenko.medvisionspring.enums;

public enum SvmExperimentStatus {
    CREATED,
    RUNNING,
    COMPLETED,
    FAILED
}
