package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.entity.AuditEvent;
import ua.nure.holovashenko.medvisionspring.entity.Hospital;
import ua.nure.holovashenko.medvisionspring.entity.User;
import ua.nure.holovashenko.medvisionspring.enums.AuditOutcome;
import ua.nure.holovashenko.medvisionspring.repository.AuditEventRepository;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuditService {
    private final AuditEventRepository repository;

    @Transactional
    public void record(User actor, Hospital hospital, String action, String resourceType,
                       String resourceId, AuditOutcome outcome, String metadata) {
        save(actor, hospital, action, resourceType, resourceId, outcome, metadata);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void recordIndependent(User actor, Hospital hospital, String action, String resourceType,
                                  String resourceId, AuditOutcome outcome, String metadata) {
        save(actor, hospital, action, resourceType, resourceId, outcome, metadata);
    }

    private void save(User actor, Hospital hospital, String action, String resourceType,
                      String resourceId, AuditOutcome outcome, String metadata) {
        repository.save(AuditEvent.builder()
                .actor(actor)
                .hospital(hospital)
                .action(action)
                .resourceType(resourceType)
                .resourceId(resourceId)
                .outcome(outcome)
                .correlationId(MDC.get("correlationId"))
                .metadata(metadata)
                .occurredAt(LocalDateTime.now())
                .build());
    }

    @Transactional(readOnly = true)
    public Page<AuditEvent> findAll(int page, int size) {
        return repository.findAllByOrderByOccurredAtDesc(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100)));
    }
}
