package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.AuditOutcome;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_event")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_event_id")
    private Long auditEventId;
    @ManyToOne
    @JoinColumn(name = "actor_user_id")
    private User actor;
    @ManyToOne
    @JoinColumn(name = "hospital_id")
    private Hospital hospital;
    @Column(name = "action", nullable = false, length = 100)
    private String action;
    @Column(name = "resource_type", length = 80)
    private String resourceType;
    @Column(name = "resource_id", length = 80)
    private String resourceId;
    @Enumerated(EnumType.STRING)
    @Column(name = "outcome", nullable = false, length = 32)
    private AuditOutcome outcome;
    @Column(name = "correlation_id", length = 64)
    private String correlationId;
    @Lob
    @Column(name = "metadata", columnDefinition = "TEXT")
    private String metadata;
    @Column(name = "occurred_at", nullable = false)
    private LocalDateTime occurredAt;
}
