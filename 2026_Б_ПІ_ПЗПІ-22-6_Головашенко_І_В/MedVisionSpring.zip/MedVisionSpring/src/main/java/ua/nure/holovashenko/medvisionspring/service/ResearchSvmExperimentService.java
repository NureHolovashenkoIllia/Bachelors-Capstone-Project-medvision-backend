package ua.nure.holovashenko.medvisionspring.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ResearchSvmExperimentService {
    private final SvmExperimentRepository experimentRepository;
    private final SvmExperimentMetricRepository metricRepository;
    private final SvmExperimentArtifactRepository artifactRepository;
    private final ResearchDatasetRepository datasetRepository;
    private final DatasetSplitAssignmentRepository splitRepository;
    private final UserRepository userRepository;
    private final SvmExperimentExecutionService executionService;
    private final BlobStorageService blobStorageService;
    private final ObjectMapper objectMapper;

    @Transactional
    public SvmExperimentDetailsResponse create(SvmExperimentCreateRequest request, UserDetails principal) {
        ResearchDataset dataset = datasetRepository.findById(request.datasetId()).orElseThrow(() -> new ApiException("Dataset not found", HttpStatus.NOT_FOUND));
        if (dataset.getStatus() != ResearchDatasetStatus.FROZEN) throw new ApiException("Only frozen datasets can be used", HttpStatus.CONFLICT);
        if (splitRepository.findAllByDataset(dataset).isEmpty()) throw new ApiException("Dataset split is missing", HttpStatus.UNPROCESSABLE_ENTITY);
        if (request.multiclassStrategy() != SvmMulticlassStrategy.ONE_VS_ONE) throw new ApiException("OpenCV C_SVC supports ONE_VS_ONE strategy", HttpStatus.UNPROCESSABLE_ENTITY);
        if (request.kernelType() != SvmKernelType.LINEAR && request.gamma() == null) throw new ApiException("gamma is required for non-linear kernels", HttpStatus.BAD_REQUEST);
        User user = userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        return map(experimentRepository.save(SvmExperiment.builder()
                .dataset(dataset)
                .modelType(request.modelType())
                .kernelType(request.kernelType())
                .cValue(request.c())
                .gammaValue(request.gamma())
                .multiclassStrategy(request.multiclassStrategy())
                .featureSet(request.featureSet())
                .seed(request.seed())
                .status(SvmExperimentStatus.CREATED)
                .createdBy(user)
                .build()));
    }

    @Transactional(readOnly = true)
    public List<SvmExperimentDetailsResponse> list(Long datasetId, SvmExperimentStatus status, SvmModelType modelType) {
        List<SvmExperiment> result;
        if (datasetId != null) {
            ResearchDataset dataset = datasetRepository.findById(datasetId).orElseThrow(() -> new ApiException("Dataset not found", HttpStatus.NOT_FOUND));
            result = experimentRepository.findAllByDatasetOrderByCreatedAtDesc(dataset);
        } else if (status != null) result = experimentRepository.findAllByStatusOrderByCreatedAtDesc(status);
        else if (modelType != null) result = experimentRepository.findAllByModelTypeOrderByCreatedAtDesc(modelType);
        else result = experimentRepository.findAllByOrderByCreatedAtDesc();
        return result.stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public SvmExperimentDetailsResponse get(Long id) {
        return map(require(id));
    }

    public SvmExperimentDetailsResponse run(Long id) {
        SvmExperiment experiment = require(id);
        if (experiment.getStatus() != SvmExperimentStatus.CREATED && experiment.getStatus() != SvmExperimentStatus.FAILED) throw new ApiException("Experiment cannot be started in current state", HttpStatus.CONFLICT);
        experiment.setStatus(SvmExperimentStatus.RUNNING);
        experiment.setStartedAt(LocalDateTime.now());
        experiment.setFinishedAt(null);
        experiment.setFailureReason(null);
        experimentRepository.save(experiment);
        executionService.execute(id);
        return map(experiment);
    }

    @Transactional(readOnly = true)
    public List<SvmExperimentMetricDto> metrics(Long id) {
        SvmExperiment experiment = requireCompleted(id);
        return metricRepository.findAllByExperimentOrderByDatasetSplitAscClassLabelAscMetricNameAsc(experiment).stream()
                .map(metric -> new SvmExperimentMetricDto(metric.getDatasetSplit(), metric.getClassLabel(), metric.getMetricName(), metric.getMetricValue()))
                .toList();
    }

    @Transactional(readOnly = true)
    public ConfusionMatrixResponse confusionMatrix(Long id) {
        SvmExperiment experiment = requireCompleted(id);
        SvmExperimentArtifact artifact = artifactRepository.findByExperimentAndArtifactType(experiment, SvmArtifactType.CONFUSION_MATRIX)
                .orElseThrow(() -> new ApiException("Confusion matrix artifact not found", HttpStatus.NOT_FOUND));
        try {
            JsonNode root = objectMapper.readTree(blobStorageService.downloadFileFromBlobUrl(artifact.getStorageUri()));
            List<Integer> labels = new ArrayList<>();
            root.get("labels").forEach(node -> labels.add(node.asInt()));
            int size = root.get("matrix").size();
            int[][] matrix = new int[size][];
            for (int i = 0; i < size; i++) {
                JsonNode row = root.get("matrix").get(i);
                matrix[i] = new int[row.size()];
                for (int j = 0; j < row.size(); j++) matrix[i][j] = row.get(j).asInt();
            }
            return new ConfusionMatrixResponse(id, labels, matrix);
        } catch (Exception exception) {
            throw new ApiException("Confusion matrix artifact cannot be read", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Transactional(readOnly = true)
    public Map<Long, List<SvmExperimentMetricDto>> compare(List<Long> ids) {
        if (ids == null || ids.size() < 2) throw new ApiException("At least two experiment IDs are required", HttpStatus.BAD_REQUEST);
        Map<Long, List<SvmExperimentMetricDto>> comparison = new LinkedHashMap<>();
        ids.stream().distinct().forEach(id -> comparison.put(id, metrics(id)));
        return comparison;
    }

    public SvmExperiment require(Long id) {
        return experimentRepository.findById(id).orElseThrow(() -> new ApiException("Experiment not found", HttpStatus.NOT_FOUND));
    }

    public SvmExperiment requireCompleted(Long id) {
        SvmExperiment experiment = require(id);
        if (experiment.getStatus() != SvmExperimentStatus.COMPLETED) throw new ApiException("Experiment is not completed", HttpStatus.CONFLICT);
        return experiment;
    }

    private SvmExperimentDetailsResponse map(SvmExperiment experiment) {
        return new SvmExperimentDetailsResponse(experiment.getExperimentId(), experiment.getDataset().getDatasetId(), experiment.getModelType(), experiment.getKernelType(), experiment.getCValue(), experiment.getGammaValue(), experiment.getMulticlassStrategy(), experiment.getFeatureSet(), experiment.getSeed(), experiment.getStatus(), experiment.getFailureReason(), experiment.getCreatedAt(), experiment.getStartedAt(), experiment.getFinishedAt());
    }
}
