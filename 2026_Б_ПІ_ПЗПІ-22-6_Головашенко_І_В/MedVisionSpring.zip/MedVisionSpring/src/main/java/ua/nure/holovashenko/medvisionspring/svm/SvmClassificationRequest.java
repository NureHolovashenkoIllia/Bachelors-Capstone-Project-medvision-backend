package ua.nure.holovashenko.medvisionspring.svm;

import java.io.File;

public record SvmClassificationRequest(
        File imageFile,
        boolean generateHeatmap,
        File modelFile,
        ModelMetrics modelMetrics
) {
    public SvmClassificationRequest(File imageFile, boolean generateHeatmap) {
        this(imageFile, generateHeatmap, null, null);
    }
}
