package ua.nure.holovashenko.medvisionspring.dto;

import ua.nure.holovashenko.medvisionspring.enums.ResearchDatasetStatus;

import java.time.LocalDateTime;
import java.util.Map;

public record ResearchDatasetResponse(
        Long datasetId,
        String name,
        String version,
        String description,
        ResearchDatasetStatus status,
        long itemCount,
        Map<Integer, Long> classDistribution,
        Map<String, Long> splitDistribution,
        LocalDateTime createdAt,
        LocalDateTime frozenAt
) {}
