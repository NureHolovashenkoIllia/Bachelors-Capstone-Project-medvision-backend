package ua.nure.holovashenko.medvisionspring.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisReviewDecision;
import ua.nure.holovashenko.medvisionspring.service.AnalysisReviewService;

import java.util.List;

@RestController
@RequestMapping("/api/research")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class ResearchReviewController {
    private final AnalysisReviewService service;

    @GetMapping("/reviewed-cases")
    public Page<AnalysisReviewResponse> reviewed(@RequestParam(required = false) Long modelVersionId,
            @RequestParam(required = false) AnalysisReviewDecision decision, @PageableDefault(size = 20) Pageable pageable) {
        return service.reviewed(modelVersionId, decision, pageable);
    }

    @PostMapping("/datasets/{datasetId}/items/from-reviews")
    public List<DatasetItemResponse> export(@PathVariable Long datasetId, @Valid @RequestBody ReviewedCasesExportRequest request,
            @AuthenticationPrincipal UserDetails principal) {
        return service.export(datasetId, request, principal);
    }
}
