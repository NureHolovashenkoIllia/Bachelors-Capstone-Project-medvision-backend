package ua.nure.holovashenko.medvisionspring.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import ua.nure.holovashenko.medvisionspring.dto.*;
import ua.nure.holovashenko.medvisionspring.entity.*;
import ua.nure.holovashenko.medvisionspring.enums.*;
import ua.nure.holovashenko.medvisionspring.exception.ApiException;
import ua.nure.holovashenko.medvisionspring.repository.*;
import ua.nure.holovashenko.medvisionspring.storage.BlobStorageService;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ResearchDatasetService {
    private final ResearchDatasetRepository datasetRepository;
    private final DatasetItemRepository itemRepository;
    private final DatasetSplitAssignmentRepository splitRepository;
    private final UserRepository userRepository;
    private final ImageFileRepository imageFileRepository;
    private final ImageAnalysisRepository analysisRepository;
    private final FileSecurityService fileSecurityService;
    private final BlobStorageService blobStorageService;

    @Transactional
    public ResearchDatasetResponse create(ResearchDatasetCreateRequest request, UserDetails principal) {
        if (datasetRepository.existsByNameAndVersion(request.name().trim(), request.version().trim())) {
            throw new ApiException("Dataset version already exists", HttpStatus.CONFLICT);
        }
        User user = currentUser(principal);
        ResearchDataset dataset = datasetRepository.save(ResearchDataset.builder()
                .name(request.name().trim())
                .version(request.version().trim())
                .description(request.description())
                .status(ResearchDatasetStatus.DRAFT)
                .createdBy(user)
                .build());
        return map(dataset);
    }

    @Transactional(readOnly = true)
    public List<ResearchDatasetResponse> list(ResearchDatasetStatus status) {
        List<ResearchDataset> datasets = status == null
                ? datasetRepository.findAllByOrderByCreatedAtDesc()
                : datasetRepository.findAllByStatusOrderByCreatedAtDesc(status);
        return datasets.stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public ResearchDatasetResponse get(Long datasetId) {
        return map(requireDataset(datasetId));
    }

    @Transactional
    public DatasetItemResponse addItem(Long datasetId, MultipartFile file, Integer classLabel, Long sourceAnalysisId, UserDetails principal) throws IOException {
        if (classLabel == null || classLabel < 0) {
            throw new ApiException("classLabel must be non-negative", HttpStatus.BAD_REQUEST);
        }
        ResearchDataset dataset = requireDraft(datasetId);
        User user = currentUser(principal);
        FileSecurityService.ValidatedUpload validated = fileSecurityService.validate(file);
        File temp = File.createTempFile("dataset-", ".img");
        String storageKey = "datasets/" + datasetId + "/" + UUID.randomUUID() + extensionFor(validated.contentType());
        try {
            file.transferTo(temp);
            String url = blobStorageService.uploadFile(temp, storageKey, validated.contentType());
            FileSecurityService.StoredMetadata metadata = fileSecurityService.metadata(temp, storageKey, validated.originalName(), validated.contentType());
            ImageFile imageFile = imageFileRepository.save(ImageFile.builder()
                    .imageFileUrl(url)
                    .imageFileName(storageKey)
                    .imageFileType(metadata.contentType())
                    .uploadedAt(LocalDateTime.now())
                    .uploadedBy(user)
                    .storageKey(metadata.storageKey())
                    .originalFileName(metadata.originalName())
                    .sizeBytes(metadata.sizeBytes())
                    .checksumSha256(metadata.checksumSha256())
                    .contentTypeVerified(true)
                    .build());
            ImageAnalysis source = sourceAnalysisId == null ? null : analysisRepository.findById(sourceAnalysisId)
                    .orElseThrow(() -> new ApiException("Source analysis not found", HttpStatus.NOT_FOUND));
            DatasetItem item = itemRepository.save(DatasetItem.builder()
                    .dataset(dataset)
                    .imageFile(imageFile)
                    .sourceAnalysis(source)
                    .classLabel(classLabel)
                    .labelSource(DatasetLabelSource.MANUAL)
                    .reviewedBy(user)
                    .reviewedAt(LocalDateTime.now())
                    .build());
            return mapItem(item, null);
        } catch (RuntimeException | IOException exception) {
            try { blobStorageService.deleteFile(storageKey); } catch (Exception ignored) { }
            throw exception;
        } finally {
            temp.delete();
        }
    }

    @Transactional
    public DatasetItemResponse updateLabel(Long itemId, DatasetLabelRequest request, UserDetails principal) {
        if (request.classLabel() == null) {
            throw new ApiException("classLabel is required", HttpStatus.BAD_REQUEST);
        }
        DatasetItem item = itemRepository.findById(itemId)
                .orElseThrow(() -> new ApiException("Dataset item not found", HttpStatus.NOT_FOUND));
        requireDraft(item.getDataset().getDatasetId());
        item.setClassLabel(request.classLabel());
        item.setLabelSource(DatasetLabelSource.MANUAL);
        item.setReviewedBy(currentUser(principal));
        item.setReviewedAt(LocalDateTime.now());
        return mapItem(itemRepository.save(item), findSplit(item));
    }

    @Transactional
    public DatasetSplitResponse split(Long datasetId, DatasetSplitCreateRequest request) {
        validateRatios(request);
        ResearchDataset dataset = requireDraft(datasetId);
        List<DatasetItem> items = itemRepository.findAllByDatasetOrderByDatasetItemId(dataset);
        if (items.size() < 3) {
            throw new ApiException("Dataset must contain at least three items", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        splitRepository.deleteAllByDataset(dataset);
        Map<Integer, List<DatasetItem>> byClass = items.stream().collect(Collectors.groupingBy(DatasetItem::getClassLabel, TreeMap::new, Collectors.toList()));
        List<DatasetSplitAssignment> assignments = new ArrayList<>();
        for (Map.Entry<Integer, List<DatasetItem>> entry : byClass.entrySet()) {
            List<DatasetItem> classItems = new ArrayList<>(entry.getValue());
            Collections.shuffle(classItems, new Random(request.seed() ^ entry.getKey()));
            int train = (int) Math.floor(classItems.size() * request.trainRatio());
            int validation = (int) Math.floor(classItems.size() * request.validationRatio());
            for (int i = 0; i < classItems.size(); i++) {
                DatasetSplit target = i < train ? DatasetSplit.TRAIN : i < train + validation ? DatasetSplit.VALIDATION : DatasetSplit.TEST;
                assignments.add(DatasetSplitAssignment.builder().datasetItem(classItems.get(i)).datasetSplit(target).seed(request.seed()).build());
            }
        }
        splitRepository.saveAll(assignments);
        return mapSplit(dataset, assignments, request.seed());
    }

    @Transactional
    public ResearchDatasetResponse freeze(Long datasetId) {
        ResearchDataset dataset = requireDraft(datasetId);
        List<DatasetItem> items = itemRepository.findAllByDatasetOrderByDatasetItemId(dataset);
        List<DatasetSplitAssignment> assignments = splitRepository.findAllByDataset(dataset);
        if (items.isEmpty() || assignments.size() != items.size()) {
            throw new ApiException("Every dataset item must have a split assignment", HttpStatus.CONFLICT);
        }
        Set<DatasetSplit> splits = assignments.stream().map(DatasetSplitAssignment::getDatasetSplit).collect(Collectors.toSet());
        if (!splits.containsAll(Set.of(DatasetSplit.TRAIN, DatasetSplit.VALIDATION, DatasetSplit.TEST))) {
            throw new ApiException("Train, validation and test splits must be non-empty", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        dataset.setStatus(ResearchDatasetStatus.FROZEN);
        dataset.setFrozenAt(LocalDateTime.now());
        return map(datasetRepository.save(dataset));
    }

    public ResearchDataset requireDataset(Long id) {
        return datasetRepository.findById(id).orElseThrow(() -> new ApiException("Dataset not found", HttpStatus.NOT_FOUND));
    }

    public ResearchDataset requireDraft(Long id) {
        ResearchDataset dataset = requireDataset(id);
        if (dataset.getStatus() != ResearchDatasetStatus.DRAFT) {
            throw new ApiException("Frozen dataset cannot be changed", HttpStatus.CONFLICT);
        }
        return dataset;
    }

    private User currentUser(UserDetails principal) {
        return userRepository.findByEmail(principal.getUsername()).orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
    }

    private void validateRatios(DatasetSplitCreateRequest request) {
        double total = request.trainRatio() + request.validationRatio() + request.testRatio();
        if (Math.abs(total - 1.0) > 0.000001 || request.trainRatio() <= 0 || request.validationRatio() <= 0 || request.testRatio() <= 0) {
            throw new ApiException("Split ratios must be positive and sum to 1.0", HttpStatus.BAD_REQUEST);
        }
    }

    private ResearchDatasetResponse map(ResearchDataset dataset) {
        List<DatasetItem> items = itemRepository.findAllByDatasetOrderByDatasetItemId(dataset);
        Map<Integer, Long> classes = items.stream().collect(Collectors.groupingBy(DatasetItem::getClassLabel, TreeMap::new, Collectors.counting()));
        Map<String, Long> splits = splitRepository.findAllByDataset(dataset).stream().collect(Collectors.groupingBy(a -> a.getDatasetSplit().name(), TreeMap::new, Collectors.counting()));
        return new ResearchDatasetResponse(dataset.getDatasetId(), dataset.getName(), dataset.getVersion(), dataset.getDescription(), dataset.getStatus(), items.size(), classes, splits, dataset.getCreatedAt(), dataset.getFrozenAt());
    }

    private DatasetSplit findSplit(DatasetItem item) {
        return splitRepository.findAllByDataset(item.getDataset()).stream().filter(a -> a.getDatasetItem().getDatasetItemId().equals(item.getDatasetItemId())).map(DatasetSplitAssignment::getDatasetSplit).findFirst().orElse(null);
    }

    public DatasetItemResponse mapItem(DatasetItem item, DatasetSplit split) {
        return new DatasetItemResponse(item.getDatasetItemId(), item.getDataset().getDatasetId(), item.getImageFile().getImageFileId(), item.getSourceAnalysis() == null ? null : item.getSourceAnalysis().getImageAnalysisId(), item.getClassLabel(), item.getLabelSource(), split, item.getReviewedBy() == null ? null : item.getReviewedBy().getUserId(), item.getReviewedAt());
    }

    private DatasetSplitResponse mapSplit(ResearchDataset dataset, List<DatasetSplitAssignment> assignments, Long seed) {
        Map<String, Long> counts = assignments.stream().collect(Collectors.groupingBy(a -> a.getDatasetSplit().name(), TreeMap::new, Collectors.counting()));
        Map<String, Map<Integer, Long>> classes = new TreeMap<>();
        for (DatasetSplit split : List.of(DatasetSplit.TRAIN, DatasetSplit.VALIDATION, DatasetSplit.TEST)) {
            classes.put(split.name(), assignments.stream().filter(a -> a.getDatasetSplit() == split).collect(Collectors.groupingBy(a -> a.getDatasetItem().getClassLabel(), TreeMap::new, Collectors.counting())));
        }
        return new DatasetSplitResponse(dataset.getDatasetId(), seed, counts, classes);
    }

    private String extensionFor(String contentType) {
        return "image/jpeg".equals(contentType) ? ".jpg" : ".png";
    }
}
