package ua.nure.holovashenko.medvisionspring.enums;

public enum AuditOutcome {
    SUCCESS,
    FAILURE,
    DENIED
}
