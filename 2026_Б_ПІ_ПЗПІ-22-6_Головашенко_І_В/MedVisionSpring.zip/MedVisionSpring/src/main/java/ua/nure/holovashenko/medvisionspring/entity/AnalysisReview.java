package ua.nure.holovashenko.medvisionspring.entity;

import jakarta.persistence.*;
import lombok.*;
import ua.nure.holovashenko.medvisionspring.enums.AnalysisReviewDecision;

import java.time.LocalDateTime;

@Entity
@Table(name = "analysis_review")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AnalysisReview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "analysis_review_id")
    private Long analysisReviewId;

    @OneToOne(optional = false)
    @JoinColumn(name = "image_analysis_id", nullable = false, unique = true)
    private ImageAnalysis imageAnalysis;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private AnalysisReviewDecision decision;

    @Column(name = "original_class", nullable = false)
    private Integer originalClass;

    @Column(name = "corrected_class")
    private Integer correctedClass;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String comment;

    @ManyToOne(optional = false)
    @JoinColumn(name = "reviewed_by_user_id", nullable = false)
    private User reviewedBy;

    @Column(name = "reviewed_at", nullable = false)
    private LocalDateTime reviewedAt;
}
