package ua.nure.holovashenko.medvisionspring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperiment;
import ua.nure.holovashenko.medvisionspring.entity.SvmExperimentArtifact;
import ua.nure.holovashenko.medvisionspring.enums.SvmArtifactType;

import java.util.List;
import java.util.Optional;

public interface SvmExperimentArtifactRepository extends JpaRepository<SvmExperimentArtifact, Long> {
    List<SvmExperimentArtifact> findAllByExperiment(SvmExperiment experiment);
    Optional<SvmExperimentArtifact> findByExperimentAndArtifactType(SvmExperiment experiment, SvmArtifactType artifactType);
    void deleteAllByExperiment(SvmExperiment experiment);
}
